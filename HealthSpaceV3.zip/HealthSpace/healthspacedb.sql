-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22-Maio-2025 às 22:10
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `healthspacedb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `anuncios`
--

CREATE TABLE `anuncios` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `rua` varchar(255) NOT NULL,
  `numero` int(5) NOT NULL,
  `cep` char(9) NOT NULL,
  `descricao` text DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL,
  `DataInicial` date NOT NULL DEFAULT '1000-01-01',
  `DataFinal` date NOT NULL DEFAULT '1000-01-01',
  `HorarioAbertura` time NOT NULL,
  `HorarioFechamento` time NOT NULL,
  `rating` decimal(10,2) NOT NULL,
  `disponibilidade` tinyint(1) DEFAULT 1,
  `TipoSala` varchar(50) NOT NULL,
  `RecursosBasicos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`RecursosBasicos`)),
  `RecursosEspecificos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`RecursosEspecificos`)),
  `nome_usuario` varchar(255) DEFAULT NULL,
  `Url_imagem_1` varchar(500) NOT NULL,
  `Url_imagem_2` varchar(500) NOT NULL,
  `Url_imagem_3` varchar(500) NOT NULL,
  `Url_imagem_4` varchar(500) NOT NULL,
  `Url_imagem_5` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `anuncios`
--

INSERT INTO `anuncios` (`id`, `id_usuario`, `nome`, `cidade`, `bairro`, `rua`, `numero`, `cep`, `descricao`, `valor`, `DataInicial`, `DataFinal`, `HorarioAbertura`, `HorarioFechamento`, `rating`, `disponibilidade`, `TipoSala`, `RecursosBasicos`, `RecursosEspecificos`, `nome_usuario`, `Url_imagem_1`, `Url_imagem_2`, `Url_imagem_3`, `Url_imagem_4`, `Url_imagem_5`) VALUES
(180, 1, 'Sala de Fisioterapia', 'Santo Antônio de Jesus', 'Nossa Senhora das Graças', 'Rua Via Coletora B', 5, '44444444', 'Sala moderna e equipada, ideal para atendimentos individuais de fisioterapia. O espaço é climatizado, possui maca profissional, espelho de parede, bola suíça, elásticos, colchonetes e outros acessórios para reabilitação e exercícios terapêuticos. Ambiente tranquilo, com iluminação natural, privacidade e conforto para o paciente.', 100.00, '2025-05-23', '2025-05-31', '18:00:00', '23:00:00', 0.00, 1, 'fisioterapia', '[\"Wi-fi\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\",\"Elevador\",\"Recepção\"]', '[\"Cama de fisioterapia\",\"Equipamento de eletroterapia\",\"Equipamento de hidroterapia\",\"Aparelho de laser\",\"Mesa de massagem\",\"Equipamento de termoterapia\"]', 'Hugo', '19i52hda43HLO2_3dxEGMz-x2cNGAWMB3', '1UVhXqhF6QVr-1Vf5xp6WblLe1SXdf4wg', '1BmESpbvgmZub_SOKbTOTpYMxPHeNYhNu', '1TUPv7-tQRmmJJklzK366cR6iOWVI0_BT', '1ngKh649DPr4_MQbY29AvoBzCCzn2S-rt'),
(181, 1, 'Sala de Odontologia', 'Recife', 'Caxangá', 'Rua Juiz Milton Lyra', 5, '50980585', 'Ambiente climatizado, higienizado e pronto para atendimentos odontológicos. A sala conta com cadeira odontológica, refletor, bancada com pia, armários, suporte para bandejas, e ponto para equipamentos odontológicos. Ideal para dentistas autônomos que buscam um espaço confortável, funcional e com excelente localização.', 59.00, '2025-05-23', '2025-06-04', '01:00:00', '19:00:00', 0.00, 1, 'odontologia', '[\"Wi-fi\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\",\"Elevador\",\"Recepção\"]', '[\"Cadeira odontológica\",\"Aparelho de raio-x\",\"Sucção\",\"Mocho\",\"Fotopolimerizador\",\"Refletor\",\"Autoclave\"]', 'Hugo', '1F2DcXQ3rUho4rz-Ss3NwlUJqYs7po-JK', '1pwuTWPiKvkppeCnE3zWoYb6cRl8iP8_e', '1klpbWQeV2Ss9n9xQKI5efr5rI_Fim8iT', '1N1qQRHiyR94OniwZVCuIqpLYLlmGgeUg', '1QYYeSywcpOwhMXr9I7Fb9n7oChIODd58'),
(182, 36, 'Sala', 'Recife', 'Caxangá', 'Rua Andreza Batista', 6, '50980425', 'a', 39.69, '2025-05-23', '2025-05-30', '10:00:00', '20:00:00', 0.00, 1, 'psicologia', '[\"Wi-fi\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\",\"Elevador\",\"Recepção\"]', '[\"Mesa de trabalho\",\"Sala de atendimento em grupo\",\"Sala de atendimento individual\",\"Cadeiras confortáveis\",\"Iluminação suave\"]', 'Julia', '1QWdCB5cgPLueora-Eo2U92xw5HnzhSgv', '1fuW-0B5LwKHO_olcvNxXgOJ8NCaxNj4o', '1amAPWJcfDvIdLjB5r0edESFrJVRppdzA', '1s8JCgPZbQi1Kjf22i90O7Naqqv0crTwY', '1Y6CmWC-rP41bwIgYa6dY8GUlYMhlWOK6'),
(183, 36, 'sdasdasd', 'Recife', 'Caxangá', 'Rua Juiz Milton Lyra', 5, '50980585', '45', 0.45, '2025-05-23', '2025-05-24', '19:00:00', '20:00:00', 0.00, 1, 'fisioterapia', '[\"Estacionamento\"]', '[\"Equipamento de hidroterapia\"]', 'Julia', '1ClEk-e5ex2QBWEIB4-cJ6ujiF3-eeHfb', '1HwczG65nstSdTB-Cro7FaQWjqIHH_C0F', '1yneZr9h0jVxvDJW1MVrKX1WggOj4I3u9', '1gIVn7wMzqtThw9aZMkZ-Ov-a0gU23Qhd', '1XXDi0vW1YBbF603bgdXVrwGhpt4v4hLV'),
(184, 37, 'Sala de Fisioterapia', 'Rio Branco', 'Conjunto Bela Vista', 'Rua Edmundo Pinto', 12, '69911328', 'Sala de fisioterapia equipada e pronta para atendimentos, oferecendo um ambiente amplo, climatizado e bem iluminado, com maca profissional, espelho de corpo inteiro, piso antiderrapante e equipamentos básicos como faixas elásticas, bolas e halteres, ideal para fisioterapeutas que buscam um espaço funcional, confortável e com privacidade para realizar tratamentos nas áreas motora, ortopédica, neurológica ou respiratória.', 49.89, '2025-05-23', '2025-05-28', '18:00:00', '20:00:00', 0.00, 1, 'psicologia', '[\"Wi-fi\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\",\"Elevador\",\"Recepção\"]', '[\"Sala de atendimento em grupo\",\"Iluminação suave\"]', 'Rafael', '1hYtpvhi3fvq063d0AT2M3oOwceZ1gRZL', '1X2FQ__CkjAiXzS4gKeF-OI-XNdsfFJrq', '1ZjivyGpUfL6a84Ak_O9Tt1vtEZuCsPsG', '1WQ3lNbKjtAxOR2dzihiv_OBlarifrq67', '16ZZSAqUg8FUWRuBhSoQL5y4SYeX5pGZ1'),
(185, 37, 'Sala de Oftalmologista', 'Brasília', 'Taguatinga Norte (Taguatinga)', 'Quadra QNL 17 Conjunto A', 15, '72151701', 'Sala de oftalmologia completa e preparada para atendimentos clínicos, equipada com cadeira oftalmológica, lâmpada de fenda, projetor de optótipos, refrator, e demais instrumentos essenciais para exames de acuidade visual e diagnóstico ocular, em um ambiente climatizado, bem iluminado, com espaço confortável e privativo, ideal para oftalmologistas que buscam um consultório funcional e pronto para realizar consultas e avaliações especializadas com segurança e eficiência.', 35.79, '2025-05-30', '2025-06-05', '17:00:00', '21:00:00', 0.00, 1, 'odontologia', '[\"Wi-fi\",\"Estacionamento\",\"Ar-condicionado\"]', '[\"Cadeira odontológica\",\"Aparelho de raio-x\",\"Sucção\"]', 'Rafael', '1ldblClwfjkXSMqA-9iE9PiPRZ88vuZtq', '1q0qr_NqiY-ks1i5Dzolr-TaLza66nRN8', '1TkfIaXCCZjWpqv9CX6GJhi7zHXQ-Urz-', '1sZyQwQst5FPSsfiFquFj378HoEfHxWnu', '1FHHblcuvb3J_YYK4rj0FDTznYJgbkgKh'),
(186, 38, 'Sala para massoterapia', 'Cacoal', 'Novo Cacoal', 'Rua Ana Rodrigues', 45, '76962210', 'Ambiente acolhedor e silencioso, ideal para atendimentos de massoterapia, relaxamento e terapias corporais. A sala conta com iluminação suave, isolamento acústico, maca profissional confortável, ar-condicionado e decoração pensada para proporcionar tranquilidade e bem-estar. Disponibilizamos também toalhas limpas, apoio para cabeça e espaço para armazenamento de materiais. Tudo pronto para que você ofereça um atendimento de qualidade com total conforto e privacidade.', 42.75, '2025-05-30', '2025-05-31', '19:00:00', '22:00:00', 0.00, 1, 'fisioterapia', '[\"Wi-fi\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\",\"Elevador\",\"Recepção\"]', '[\"Equipamento de eletroterapia\",\"Cama de fisioterapia\",\"Equipamento de hidroterapia\"]', 'Jorge', '1rkIlVNkjCgzVnkN5Pk9u3A7Ex-yW1yi6', '1xwnA-zLaCTMMa7AlCmNWfOpGJy8Bc0HE', '1P9Hn5DF4CqFbWF5_sjX3W1Mjc7WbOgXK', '1JcALclA0Oel-X_DPW3kLjXOSrMdxWBaF', '16E1QdPGPoqoSXI-c3YNH_Vi2sLPPKVNo'),
(187, 1, 'Sala de fisioterapia', 'Ji-Paraná', 'Mutirão', 'Rua Andorinha', 41, '76909658', 'Sala equipada e preparada para atendimentos de fisioterapia, reabilitação e exercícios terapêuticos. O espaço conta com maca ortopédica, espaldar, bolas terapêuticas, colchonetes, halteres e outros acessórios essenciais para sessões funcionais. Ambiente climatizado, com boa ventilação, iluminação natural e piso adequado para práticas seguras. Ideal para fisioterapeutas que buscam um local profissional, confortável e pronto para atender seus pacientes com qualidade e privacidade.', 105.45, '2025-06-07', '2025-07-10', '17:00:00', '22:00:00', 0.00, 1, 'fisioterapia', '[\"Wi-fi\",\"Elevador\"]', '[\"Aparelho de laser\"]', 'Hugo', '1B2SxNZnTQvwwQFLm67DlmpAeCAMhXFkB', '1E-af0YbLpZ2jbBz3PeVS7NKupJU7cDyM', '1JuCdAd-kBJwTLPUZK498ghOHxmfsjtGf', '1aHKBUTlfGhuddIdSlW8sBpDd7UyR7XfR', '1-Xs71AR2YC0nqRJN2qOixmMqxfegeU-X');

-- --------------------------------------------------------

--
-- Estrutura da tabela `datas`
--

CREATE TABLE `datas` (
  `id_data` int(11) NOT NULL,
  `id_anuncio` int(11) NOT NULL,
  `Data_Disponivel` date NOT NULL,
  `Status` enum('Disponivel','Reservado','Cancelada','Concluida','Expirada') NOT NULL DEFAULT 'Disponivel'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `datas`
--

INSERT INTO `datas` (`id_data`, `id_anuncio`, `Data_Disponivel`, `Status`) VALUES
(176, 180, '2025-05-23', 'Reservado'),
(177, 180, '2025-05-24', 'Reservado'),
(178, 180, '2025-05-25', 'Reservado'),
(179, 180, '2025-05-26', 'Reservado'),
(180, 180, '2025-05-27', 'Reservado'),
(181, 180, '2025-05-28', 'Reservado'),
(182, 180, '2025-05-29', 'Reservado'),
(183, 180, '2025-05-30', 'Reservado'),
(184, 180, '2025-05-31', 'Reservado'),
(185, 181, '2025-05-23', 'Reservado'),
(186, 181, '2025-05-24', 'Reservado'),
(187, 181, '2025-05-25', 'Reservado'),
(188, 181, '2025-05-26', 'Reservado'),
(189, 181, '2025-05-27', 'Reservado'),
(190, 181, '2025-05-28', 'Reservado'),
(191, 181, '2025-05-29', 'Reservado'),
(192, 181, '2025-05-30', 'Reservado'),
(193, 181, '2025-05-31', 'Reservado'),
(194, 181, '2025-06-01', 'Reservado'),
(195, 181, '2025-06-02', 'Reservado'),
(196, 181, '2025-06-03', 'Disponivel'),
(197, 181, '2025-06-04', 'Disponivel'),
(198, 182, '2025-05-23', 'Reservado'),
(199, 182, '2025-05-24', 'Reservado'),
(200, 182, '2025-05-25', 'Reservado'),
(201, 182, '2025-05-26', 'Reservado'),
(202, 182, '2025-05-27', 'Reservado'),
(203, 182, '2025-05-28', 'Reservado'),
(204, 182, '2025-05-29', 'Reservado'),
(205, 182, '2025-05-30', 'Reservado'),
(206, 183, '2025-05-23', 'Disponivel'),
(207, 183, '2025-05-24', 'Disponivel'),
(208, 184, '2025-05-23', 'Disponivel'),
(209, 184, '2025-05-24', 'Disponivel'),
(210, 184, '2025-05-25', 'Disponivel'),
(211, 184, '2025-05-26', 'Disponivel'),
(212, 184, '2025-05-27', 'Disponivel'),
(213, 184, '2025-05-28', 'Disponivel'),
(214, 185, '2025-05-30', 'Disponivel'),
(215, 185, '2025-05-31', 'Disponivel'),
(216, 185, '2025-06-01', 'Disponivel'),
(217, 185, '2025-06-02', 'Disponivel'),
(218, 185, '2025-06-03', 'Disponivel'),
(219, 185, '2025-06-04', 'Disponivel'),
(220, 185, '2025-06-05', 'Disponivel'),
(221, 186, '2025-05-30', 'Disponivel'),
(222, 186, '2025-05-31', 'Disponivel'),
(223, 187, '2025-06-07', 'Disponivel'),
(224, 187, '2025-06-08', 'Disponivel'),
(225, 187, '2025-06-09', 'Disponivel'),
(226, 187, '2025-06-10', 'Disponivel'),
(227, 187, '2025-06-11', 'Disponivel'),
(228, 187, '2025-06-12', 'Disponivel'),
(229, 187, '2025-06-13', 'Disponivel'),
(230, 187, '2025-06-14', 'Disponivel'),
(231, 187, '2025-06-15', 'Disponivel'),
(232, 187, '2025-06-16', 'Disponivel'),
(233, 187, '2025-06-17', 'Disponivel'),
(234, 187, '2025-06-18', 'Disponivel'),
(235, 187, '2025-06-19', 'Disponivel'),
(236, 187, '2025-06-20', 'Disponivel'),
(237, 187, '2025-06-21', 'Disponivel'),
(238, 187, '2025-06-22', 'Disponivel'),
(239, 187, '2025-06-23', 'Disponivel'),
(240, 187, '2025-06-24', 'Disponivel'),
(241, 187, '2025-06-25', 'Disponivel'),
(242, 187, '2025-06-26', 'Disponivel'),
(243, 187, '2025-06-27', 'Disponivel'),
(244, 187, '2025-06-28', 'Disponivel'),
(245, 187, '2025-06-29', 'Disponivel'),
(246, 187, '0000-00-00', 'Disponivel'),
(247, 187, '0000-00-00', 'Disponivel'),
(248, 187, '0000-00-00', 'Disponivel'),
(249, 187, '0000-00-00', 'Disponivel'),
(250, 187, '0000-00-00', 'Disponivel'),
(251, 187, '0000-00-00', 'Disponivel'),
(252, 187, '0000-00-00', 'Disponivel'),
(253, 187, '0000-00-00', 'Disponivel'),
(254, 187, '0000-00-00', 'Disponivel'),
(255, 187, '0000-00-00', 'Disponivel'),
(256, 187, '0000-00-00', 'Disponivel');

-- --------------------------------------------------------

--
-- Estrutura da tabela `reservas_confirmadas`
--

CREATE TABLE `reservas_confirmadas` (
  `id_reserva` int(11) NOT NULL,
  `id_anuncio` int(11) NOT NULL,
  `id_reservante` int(11) NOT NULL,
  `Data_Reservada` date NOT NULL,
  `ValorPago` float NOT NULL,
  `Data` datetime NOT NULL,
  `Codigo_reserva` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `reservas_confirmadas`
--

INSERT INTO `reservas_confirmadas` (`id_reserva`, `id_anuncio`, `id_reservante`, `Data_Reservada`, `ValorPago`, `Data`, `Codigo_reserva`) VALUES
(74, 180, 36, '2025-05-23', 200, '0000-00-00 00:00:00', '36-180-de57bd99-682e-475a-9f31-c1da43aa6585'),
(75, 180, 36, '2025-05-24', 200, '0000-00-00 00:00:00', '36-180-de57bd99-682e-475a-9f31-c1da43aa6585'),
(76, 180, 36, '2025-05-25', 700, '0000-00-00 00:00:00', '36-180-af4e8049-208b-4877-8ec1-81324d6cec74'),
(77, 180, 36, '2025-05-26', 700, '0000-00-00 00:00:00', '36-180-af4e8049-208b-4877-8ec1-81324d6cec74'),
(78, 180, 36, '2025-05-27', 700, '0000-00-00 00:00:00', '36-180-af4e8049-208b-4877-8ec1-81324d6cec74'),
(79, 180, 36, '2025-05-28', 700, '0000-00-00 00:00:00', '36-180-af4e8049-208b-4877-8ec1-81324d6cec74'),
(80, 180, 36, '2025-05-29', 700, '0000-00-00 00:00:00', '36-180-af4e8049-208b-4877-8ec1-81324d6cec74'),
(81, 180, 36, '2025-05-30', 700, '0000-00-00 00:00:00', '36-180-af4e8049-208b-4877-8ec1-81324d6cec74'),
(82, 180, 36, '2025-05-31', 700, '0000-00-00 00:00:00', '36-180-af4e8049-208b-4877-8ec1-81324d6cec74'),
(83, 181, 36, '2025-06-01', 118, '0000-00-00 00:00:00', '36-181-42c3787b-c7cd-4a36-829b-5a5ee9e3f559'),
(84, 181, 36, '2025-06-02', 118, '0000-00-00 00:00:00', '36-181-42c3787b-c7cd-4a36-829b-5a5ee9e3f559');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `senha` varchar(500) NOT NULL,
  `HCoins` bigint(11) NOT NULL,
  `role` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nome`, `email`, `senha`, `HCoins`, `role`) VALUES
(1, 'Hugo', 'Hugo@gmail.com', '$2b$10$LTmc5F.TBZh2sRCvw9F11OJaE62QMTPiac/i37IWx8LAVHvPUVAbG', 9223372036846539000, 'user'),
(36, 'Julia', 'Julia@gmail.com', '$2b$10$AM4w1YrPelml3JJJPQXn9.ChLFuLyQ8JcjZr2Aw3ez7KXmXNfly/a', 460, 'user'),
(37, 'Rafael', 'Rafael@gmail.com', '$2b$10$hyqReh/WQF7i8m1sOajqBeeBX4x6GxDwd5bB60xym/EaVZ/YD09Uu', 0, 'user'),
(38, 'Jorge', 'Jorge@gmail.com', '$2b$10$nbASevDnZo/b2BpJ6SZK.enVr1m9SSrkmIjJMGJ9B/2cwvJsWZyie', 0, 'user');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `anuncios`
--
ALTER TABLE `anuncios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Índices para tabela `datas`
--
ALTER TABLE `datas`
  ADD PRIMARY KEY (`id_data`),
  ADD KEY `id_anuncio` (`id_anuncio`);

--
-- Índices para tabela `reservas_confirmadas`
--
ALTER TABLE `reservas_confirmadas`
  ADD PRIMARY KEY (`id_reserva`),
  ADD KEY `id` (`id_reservante`),
  ADD KEY `id_ad` (`id_anuncio`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `anuncios`
--
ALTER TABLE `anuncios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;

--
-- AUTO_INCREMENT de tabela `datas`
--
ALTER TABLE `datas`
  MODIFY `id_data` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- AUTO_INCREMENT de tabela `reservas_confirmadas`
--
ALTER TABLE `reservas_confirmadas`
  MODIFY `id_reserva` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `anuncios`
--
ALTER TABLE `anuncios`
  ADD CONSTRAINT `anuncios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Limitadores para a tabela `datas`
--
ALTER TABLE `datas`
  ADD CONSTRAINT `id_anuncio` FOREIGN KEY (`id_anuncio`) REFERENCES `anuncios` (`id`);

--
-- Limitadores para a tabela `reservas_confirmadas`
--
ALTER TABLE `reservas_confirmadas`
  ADD CONSTRAINT `id` FOREIGN KEY (`id_reservante`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `id_ad` FOREIGN KEY (`id_anuncio`) REFERENCES `anuncios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
