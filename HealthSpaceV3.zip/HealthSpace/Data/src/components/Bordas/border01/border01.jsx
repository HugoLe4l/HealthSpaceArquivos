import "./border01.css"


function Border01 () {
    return(
        <hr className="Border01"/>
    )
}

export default Border01 