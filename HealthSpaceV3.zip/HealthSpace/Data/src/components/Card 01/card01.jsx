import "./card01.css"
import { useEffect, useRef, useState } from "react"
import { useNavigate } from "react-router-dom"

import Not_Image_Card from "../../../public/Assets/Imagens/Not_Image_Card.jpg"
function Card01( { anuncio }) {

    const RefBtnFavorito = useRef(null)
    const Navigate = useNavigate()
    const [imagem01 , setimagem01] = useState('esperando')
    //console.log(`https://drive.google.com/thumbnail?id=${anuncio[0].Url_imagem_1}`)

    return (
        <div className="Card_01" onClick={ () => Navigate(`/anuncios/${ anuncio[0].id}`)}>
            <div className="Card_01_Content">
                <div className="Card_01_Image" style={{backgroundImage : anuncio[0].Url_imagem_1  ? `url(https://drive.google.com/thumbnail?id=${anuncio[0].Url_imagem_1})` :  `url(${Not_Image_Card})`}}>
                </div>
                <hr />
                <div className="Card_01_Infos">

                    <h4 className="NomeAnuncioCard">{anuncio[0].nome}</h4>
                    <p>Anunciado por <strong className="Card_01_Link_Anunciante">{anuncio[0].nome_usuario}</strong></p>
                    <p className="Card_01_Rating"><i class="bi bi-star-fill">{anuncio[0].rating}</i></p>
                    <div className="Card_01_Loc">
                        <i class="bi bi-geo-alt-fill"></i>
                        <p className="Card01_Endereco">{anuncio[0].cidade}, {anuncio[0].bairro}</p>
                    </div>
                    <p>R$ { parseFloat(anuncio[0].valor)?.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })   }/dia</p>
                </div>
                <i ref={RefBtnFavorito} class="btn_favorito bi bi-heart" onClick={() => { BtnFavoritoClickStyle()}}></i>
            </div>

        </div>
    )

    function BtnFavoritoClickStyle () {
        RefBtnFavorito.current.classList.toggle("bi-heart")
        RefBtnFavorito.current.classList.toggle("bi-heart-fill")
        RefBtnFavorito.current.style.color = "white"

        //Aqui depois vamos colocar para adicionar aos favoritos
    }
}

export default Card01