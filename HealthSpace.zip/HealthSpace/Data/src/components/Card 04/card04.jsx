import "./Card04.css"
import { useState } from "react"
import { useNavigate } from "react-router-dom"

function Card04({ Dados }) {
    const navigate = useNavigate()
    
    const [DadosAnuncio, setDadosAnuncio] = useState({
        Id: Dados?.anuncio.id,
        Nome: Dados?.anuncio.nome,
        Propietario: Dados?.anuncio.nome_usuario,
        HorarioAbertura: Dados?.anuncio.HorarioAbertura,
        HorarioFechamento: Dados?.anuncio.HorarioFechamento,
        Valor: Dados?.anuncio.valor,
        Imagem1: Dados?.anuncio.Url_imagem_1
    })

    const Reservas = Dados?.reservas ? Dados?.reservas : []
    console.log(Reservas)
    const [Exibir, setExibir] = useState(false)
    const url = 'https://drive.google.com/thumbnail?id='
    return (
        <div className="Card04">
            <div className="Card04_Top">

                <div className="Card04_content">

                    <div className="Img" style={{ backgroundImage: `url(${url}${DadosAnuncio.Imagem1})` }} onClick={() => navigate(`/anuncios/${DadosAnuncio.Id}`)} ></div>

                    <div className="Card04_Right">
                        <div className="Card04_infos">
                            <h4 onClick={() => navigate(`/anuncios/${DadosAnuncio.Id}`)} >{DadosAnuncio.Nome}</h4>
                            <p className="Card04_Valor">R$ {DadosAnuncio.Valor}</p>
                            <p className="Card04_Propietario">Proprietario: <strong>{DadosAnuncio.Propietario}</strong></p>

                            <div className="Card04_Periodos">
                                <i class="bi bi-clock-history"></i>
                                <div className="Card04_Datas">
                                    <p>{DadosAnuncio.HorarioAbertura?.slice(0, 5)}</p>
                                    á
                                    <p>{DadosAnuncio.HorarioFechamento?.slice(0, 5)}</p>
                                </div>
                                |

                                <div className="Card04_Rating">
                                    <i class="bi bi-star-fill"></i>
                                    <p>4.78</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <p className="codigo">#{DadosAnuncio.Id}</p>
            </div>

            <div className="Card04_Bottom"  >
                <div className="Btn_ExibirReservas" onClick={() => setExibir(!Exibir)} >
                    <i class="bi bi-menu-button-wide"></i>
                    <p>{Exibir ? "Ocultar" : "Exibir"} minhas reservas {`( ${Dados.reservas.length} )`}</p>
                    <div className="icon" style={{ rotate: Exibir ? "180deg" : "360deg" }}>
                        <i class="bi bi-chevron-down" ></i>
                    </div>
                </div>

                <div className="Card04_Bottom_Content" style={{ maxHeight: Exibir ? "1000px" : "0px" }}>
                    <div className="Card04_Bottom_Content_interno">

                        {
                            Reservas.map((reserva, index) => {
                                return (
                                    <div className="Card04_Reserva_Dados">

                                        <div className="Card04_Reserva_Dados_row1">
                                            <div>
                                                <p>#{index + 1}</p>
                                                <div>
                                                    <p>Codigo da reserva: </p>
                                                    <p className="Card04_CodigoReserva">{reserva.Codigo_reserva}</p>
                                                </div>
                                            </div>
                                            <i class="bi bi-exclamation-circle"></i>
                                        </div>


                                        <div className="Card04_Reserva_Dados_row2">

                                            <div className="Card04_Reserva_Dados_Datas">
                                                <div className="Card04_Reserva_Dados_Datas_row1">
                                                    <i class="bi bi-calendar2-check"></i>
                                                    <p>Datas reservadas</p>
                                                </div>

                                                <div className="Card04_Reserva_Dados_Datas_row2">
                                                    {
                                                        reserva.datas.map( (data, index ) => {
                                                            const Dataformatada = new Date(data).toLocaleDateString('pt-BR')
                                                            return(
                                                                <p>{Dataformatada}</p>
                                                            )
                                                        })
                                                    }
                                                </div>
                                            </div>

                                            <div className="Card04_Reserva_Options_Btn">
                                                <button>Cancelar</button>
                                            </div>

                                        </div>
                                    </div>

                                )
                            })
                        }









                        <div className="Card04_Datas_Reservadas"></div>
                    </div>
                </div>

            </div>

        </div>
    )

}
//
export default Card04