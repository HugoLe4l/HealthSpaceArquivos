import "./card03.css"
import { useState } from "react"
import { useNavigate } from "react-router-dom"

function Card03({ Dados }) {
    const navigate = useNavigate()
    const [DadosAnuncio, setDadosAnuncio] = useState({
        Id: Dados?.id,
        Nome: Dados?.nome,
        DataInicial: new Date(Dados?.DataInicial),
        DataFinal: new Date(Dados?.DataFinal),
        Valor: Dados?.valor,
        Imagem1: Dados?.Url_imagem_1

    })

    const [Exibir, setExibir] = useState(false)
    const url = 'https://drive.google.com/thumbnail?id='
    return (
        <div className="Card03">
            <div className="Card03_Top">

                <div className="Card03_content">

                    <div className="Img" style={{ backgroundImage: `url(${url}${DadosAnuncio.Imagem1})` }} onClick={() => navigate(`/anuncios/${DadosAnuncio.Id}`)} ></div>

                    <div className="Card03_Right">
                        <div className="Card03_infos">
                            <h4 onClick={() => navigate(`/anuncios/${DadosAnuncio.Id}`)}>{DadosAnuncio.Nome}</h4>
                            <p className="Card03_Valor">R$ {DadosAnuncio.Valor}</p>

                            <div className="Card03_Periodos">
                                <i class="bi bi-calendar4-week"></i>
                                <div className="Card03_Datas">
                                    <p>{DadosAnuncio.DataInicial.toLocaleDateString()}</p>
                                    á
                                    <p>{DadosAnuncio.DataFinal.toLocaleDateString()}</p>
                                </div>
                                |

                                <div className="Card03_Rating">
                                    <i class="bi bi-star-fill"></i>
                                    <p>4.78</p>
                                </div>
                            </div>
                        </div>

                        <div className="Card03_Options">
                            <div className="Card03_Opcao">
                                <i class="bi bi-pencil-square"></i>
                                <p>Editar</p>
                            </div>
                            <div className="Card03_Opcao">
                                <i class="bi bi-pause-circle"></i>
                                <p>Pausar</p>
                            </div>
                            <div className="Card03_Opcao">
                                <i class="bi bi-trash3-fill"></i>
                                <p>Excluir</p>
                            </div>
                        </div>
                    </div>

                </div>

                <p className="codigo">#{DadosAnuncio.Id}</p>
            </div>

            <div className="Card03_Bottom"  >
                <div className="Btn_ExibirReservas" onClick={() => setExibir(!Exibir)} >
                    <i class="bi bi-menu-button-wide"></i>
                    <p>{Exibir ? "Ocultar" : "Exibir"} reservas</p>
                    <div className="icon" style={{ rotate: Exibir ? "180deg" : "360deg" }}>
                        <i class="bi bi-chevron-down" ></i>
                    </div>
                </div>
                <div className="Card03_Bottom_Content" style={{ maxHeight: Exibir ? "1000px" : "0px" }}>
                    <div className="Card03_Bottom_Content_interno">
                        <div className="Card03_Datas_Livres">
                            <p>22/10/2025</p>
                        </div>
                        <div className="Card03_Datas_Reservadas"></div>
                    </div>
                </div>
            </div>

        </div>
    )

}
//
export default Card03