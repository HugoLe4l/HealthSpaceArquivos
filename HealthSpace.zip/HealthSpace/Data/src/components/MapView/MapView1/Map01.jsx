import "./Map01.css";
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { useState, useEffect } from "react";

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

function Map01() {
    const [Longitude, setLongitude] = useState(null);
    const [Latitude, setLatitude] = useState(null);
    const endereco = "Rua Juiz Milton Lyra, 06, Recife, Brasil";

    useEffect(() => {
        fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(endereco)}&format=json&addressdetails=1&limit=1`)
            .then(res => res.json())
            .then(data => {
                if (data.length > 0) {
                    setLatitude(parseFloat(data[0].lat));
                    setLongitude(parseFloat(data[0].lon));
                }
            })
            .catch(err => console.error("Erro ao buscar coordenadas:", err));
    }, []);

    useEffect(() => {
        console.log(`Latitude: ${Latitude} - Longitude${Longitude}`);

    }, [Latitude, Longitude])

    if (!Latitude || !Longitude) return <p>Carregando mapa...</p>;

    const position = [Latitude, Longitude];

    return (
        <div>
            <MapContainer center={position} zoom={13} scrollWheelZoom={false}>
                <TileLayer
                    attribution='&copy; <a href="https://carto.com/">Carto</a>'
                    url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
                />

                <Marker position={position}>
                    <Popup>{Latitude} - {Longitude}</Popup>
                </Marker>
            </MapContainer>
        </div>
    );
}

export default Map01;
