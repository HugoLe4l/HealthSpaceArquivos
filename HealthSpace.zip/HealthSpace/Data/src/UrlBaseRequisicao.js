const local = {
    url: "http://localhost:8081"
}
const vercel = {
    url: ""
}

const BaseUrl = local

export default BaseUrl