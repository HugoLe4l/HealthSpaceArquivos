import { useEffect, useState, useRef } from "react"
import axios from "axios"
import "./MinhasReservas.css"

//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao.js"

import Header02 from "../../components/Header02/header02.jsx"
import Footer02 from "../../components/Footer02/footer02.jsx"
import Card02 from "../../components/Card 02/card02.jsx"
import Card04 from "../../components/Card 04/card04.jsx"

//icons
import GatoTriste from "../../../public/Assets/Icons/GatoTriste.png"

function MinhasReservas() {

    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(false)

    const [ArrayMeusAnunciosConfirmados, setArrayMeusAnunciosConfirmados] = useState([])
    const [TemReservas, setTemReservas] = useState()

    const [MenuOpcaoSelecionada, setMenuOpcaoSelecionada] = useState(1)

    useEffect(() => {
        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        //console.log(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                            })

                    } else {
                        setStatusLogin(false)
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)

        }

    }, [])

    useEffect(() => {
        if (InfosUser.id_usuario) {
            console.log(InfosUser.id_usuario)
            axios.post(`${BaseUrl.url}/anuncio/reservas-confirmadas`, { id_usuario: InfosUser.id_usuario })
                .then(resposta => {
                    if (resposta.data['MeusAnunciosConfirmados'].length > 0) {
                        //console.log(resposta.data)
                        console.log(`ID DO USUARIO: ${InfosUser.id_usuario}`)
                        setArrayMeusAnunciosConfirmados(resposta.data['MeusAnunciosConfirmados'])
                        setTemReservas(true)
                    } else {
                        setTemReservas(false)
                    }

                })
                .catch(err => {
                    console.error("Erro:", err);
                });
        }

    }, [InfosUser])

    return (
        <>
            <Header02 InfosUser={InfosUser} StatusLogin={StatusLogin} />

            <main className="Page_MinhaReserva">

                <section className="Section01_MinhaReserva">
                    <div className="titulo_page">
                        <i class="bi bi-journals"></i>
                        <h2>Minhas reservas</h2>
                    </div>
                    <nav className="MinhaReserva_Menu">

                        <div className={`Box_MinhaReserva_Option ${MenuOpcaoSelecionada === 1 ? "MenuOpcaoSelect" : ""}`} onClick={() => setMenuOpcaoSelecionada(1)}>
                            <p>Ativas  0 </p>
                        </div>

                        <div className={`Box_MinhaReserva_Option ${MenuOpcaoSelecionada === 2 ? "MenuOpcaoSelect" : ""}`} onClick={() => setMenuOpcaoSelecionada(2)} >
                            <p>Concluidas 0</p>
                        </div>
                    </nav>
                </section>


                <div className="Box_Minhas_Reserva_Cards">

                    {MenuOpcaoSelecionada === 1 && (
                        Array.isArray(ArrayMeusAnunciosConfirmados) && ArrayMeusAnunciosConfirmados.map((item, index) => {

                            return (
                                <Card04 key={index} Dados={item} />
                            )
                        })
                    )}

                    <div className="AvisoReserva" style={{ display: TemReservas ? "none" : "flex" }}>
                        <img src={GatoTriste} alt="" />
                        <p>Você não tem nenhuma reserva no momento. :(</p>

                    </div>

                </div>

            </main>
            <Footer02 />
        </>
    )
}

export default MinhasReservas