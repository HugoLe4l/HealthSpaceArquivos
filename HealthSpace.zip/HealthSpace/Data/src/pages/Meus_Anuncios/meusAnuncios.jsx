import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from 'axios'
import "./meusAnuncios.css"

//Components
import Header02 from "../../components/Header02/header02.jsx"
import Footer02 from "../../components/Footer02/footer02.jsx"
import Border01 from "../../components/Bordas/border01/border01.jsx";
import Card03 from "../../components/Card 03/card03.jsx";
//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao.js";


function MeusAnunciosPage() {

    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(true)
    const navigate = useNavigate()

    const [MenuOpcaoSelecionada, setMenuOpcaoSelecionada] = useState(1)
    const [ArrayListaAnuncios, setArrayListaAnuncios] = useState([])

    useEffect(() => {
        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        //console.log(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                                BuscaMeusAnuncios(id)
                            })

                    } else {
                        setStatusLogin(false)
                        navigate('/')
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)
            navigate('/')

        }
    }, [])

    return (
        <>
            <Header02 InfosUser={InfosUser} StatusLogin={StatusLogin} />
            <main className="Page_MeusAnuncios">
                <section className="Section01_MeusAnuncios">
                    <div className="titulo_page">
                        <i class="bi bi-bookmark-check"></i>
                        <h2>Meus anúncios</h2>
                    </div>
                    <nav className="MeuAnuncio_Menu">

                        <div className={`Box_MenuAnuncio_Option ${MenuOpcaoSelecionada === 1 ? "MenuOpcaoSelect" : ""}`} onClick={() => setMenuOpcaoSelecionada(1)}>
                            <p>Publicados {ArrayListaAnuncios.length}</p>
                        </div>

                        <div className={`Box_MenuAnuncio_Option ${MenuOpcaoSelecionada === 2 ? "MenuOpcaoSelect" : ""}`} onClick={() => setMenuOpcaoSelecionada(2)} >
                            <p>Pausados 0</p>
                        </div>

                        <div className={`Box_MenuAnuncio_Option ${MenuOpcaoSelecionada === 3 ? "MenuOpcaoSelect" : ""}`} onClick={() => setMenuOpcaoSelecionada(3)}>
                            <p>Excluidos 0</p>
                        </div>

                    </nav>
                </section>

                <section className="Section02_MeusAnuncios">
                    {MenuOpcaoSelecionada === 1 && (
                        ArrayListaAnuncios.length > 0 ? (

                            <div className="Box_cards">
                                {ArrayListaAnuncios.map((item, index) => {
                                    return (
                                        <Card03 key={index} Dados={item}/>
                                    )
                                })}
                            </div>

                        ) : (
                            <p>Nenhum anúncio registrado</p>
                        )
                    )}


                </section>
            </main>
            <Footer02 />
        </>
    )

    function BuscaMeusAnuncios(id) {
        axios.post(`${BaseUrl.url}/anuncio/lista-meus-anuncios`, { id: id })
            .then(resposta => {
                console.log(resposta.data)
                setArrayListaAnuncios(resposta.data['Resultado'])
            })

            .catch(error => {
                console.log(error)
            })
    }
}

export default MeusAnunciosPage