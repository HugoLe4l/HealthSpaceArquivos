import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import axios from 'axios'
import "./novoAnuncio.css"

//Components
import Header02 from "../../components/Header02/header02.jsx";
import Footer02 from "../../components/Footer02/footer02.jsx";
import Loading01 from "../../components/loading01/loading01.jsx";


//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao.js";

//Imagens
import ImagemEpaço1 from "../../../public/Assets/Imagens/ImagemEspaço1.png"

function NovoAnuncioPage() {
    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(true)
    const navigate = useNavigate()

    const [etapaAtual, setEtapaAtual] = useState(1);
    const avancar = () => {
        if (etapaAtual === 9 && Etapa_Todas_Preenchido) {
            console.log('Iniciando Função Cadastro...');
            CriarAnuncio(event)
        } else {
            setEtapaAtual(prev => prev + 1);
            setContadorBarraProgresso(prev => prev + 11.11)
        }
    };
    const voltar = () => {
        setEtapaAtual(prev => prev - 1);
        setContadorBarraProgresso(prev => prev - 11.11)
    };
    const [Etapa1_Preenchido, setEtapa1_Preenchido] = useState(true)
    const [Etapa2_Preenchido, setEtapa2_Preenchido] = useState(false)
    const [Etapa3_Preenchido, setEtapa3_Preenchido] = useState(false)
    const [Etapa4_Preenchido, setEtapa4_Preenchido] = useState(false)
    const [Etapa5_Preenchido, setEtapa5_Preenchido] = useState(false)
    const [Etapa7_Preenchido, setEtapa7_Preenchido] = useState(false)
    const [Etapa9_Preenchido, setEtapa9_Preenchido] = useState(false)


    const [Etapa_Todas_Preenchido, setEtapa_Todas_Preenchido] = useState(false)

    const [DadosNovoAnuncio, setDadosNovoAnuncio] = useState({
        InfosBasicas: { Titulo: "", Cep: "", Cidade: "", Bairro: "", Uf: "", Numero: "", Rua: "" },
        Recursos: { RecursosBasicos: "", RecursosEspecificos: { TipoSala: "", Recursos: "" } },
        Horarios: { Abertura: "", Fechamento: "" },
        Datas: { Inicial: "", Final: "" },
        Valor: "",
        Descricao: "",
        Imagens: { Imagem1: "", Imagem2: "", Imagem3: "", Imagem4: "", Imagem5: "" }

    })

    // > Etapa 2 Inicio
    const [nomeAnuncioLength, setnomeAnuncioLength] = useState(0)
    const [numero, setNumero] = useState("");

    const [VerificaCEP, setVerificaCEP] = useState()
    //Refs input style
    const RefsInputEndereco = {
        RefInputTitulo: useRef(null),
        RefInputCEP: useRef(null),
        RefInputCidade: useRef(null),
        RefInputBairro: useRef(null),
        RefInputUF: useRef(null),
        RefInputRua: useRef(null),
        RefInputNumero: useRef(null),
    }
    //Refs Style Input Icons verificados
    const RefsIconsVerificacaoEndereco = {
        Titulo: useRef(null),
        Cep: useRef(null),
        Cidade: useRef(null),
        Bairro: useRef(null),
        Numero: useRef(null),
        Rua: useRef(null),
        Uf: useRef(null),
    }
    //Style de resposta do campo CEP
    useEffect(() => {
        if (RefsInputEndereco.RefInputCEP.current.value.length > 0) {
            if (VerificaCEP === true) {
                RefsIconsVerificacaoEndereco.Cep.current.style.color = "yellowgreen"
                RefsIconsVerificacaoEndereco.Cep.current.classList.remove('bi-patch-exclamation')
                RefsIconsVerificacaoEndereco.Cep.current.classList.add('bi-patch-check')

                RefsIconsVerificacaoEndereco.Cidade.current.style.color = "yellowgreen"
                RefsIconsVerificacaoEndereco.Cidade.current.classList.add('bi-patch-check')

                RefsIconsVerificacaoEndereco.Bairro.current.style.color = "yellowgreen"
                RefsIconsVerificacaoEndereco.Bairro.current.classList.add('bi-patch-check')

                RefsIconsVerificacaoEndereco.Rua.current.style.color = "yellowgreen"
                RefsIconsVerificacaoEndereco.Rua.current.classList.add('bi-patch-check')

                RefsIconsVerificacaoEndereco.Uf.current.style.color = "yellowgreen"
                RefsIconsVerificacaoEndereco.Uf.current.classList.add('bi-patch-check')


                const inputs = [
                    RefsInputEndereco.RefInputCEP.current,
                    RefsInputEndereco.RefInputCidade.current,
                    RefsInputEndereco.RefInputBairro.current,
                    RefsInputEndereco.RefInputRua.current,
                    RefsInputEndereco.RefInputUF.current
                ]
                inputs.forEach(input => {
                    input.style.border = "1px solid yellowgreen"
                })




            } else {
                RefsIconsVerificacaoEndereco.Cep.current.style.color = "red"
                RefsIconsVerificacaoEndereco.Cep.current.classList.remove('bi-patch-check')
                RefsIconsVerificacaoEndereco.Cep.current.classList.add('bi-patch-exclamation')
                RefsInputEndereco.RefInputCEP.current.style.border = "1px solid red"

                RefsIconsVerificacaoEndereco.Cidade.current.classList.remove('bi-patch-check')
                RefsIconsVerificacaoEndereco.Bairro.current.classList.remove('bi-patch-check')
                RefsIconsVerificacaoEndereco.Rua.current.classList.remove('bi-patch-check')
                RefsIconsVerificacaoEndereco.Uf.current.classList.remove('bi-patch-check')



                const inputs = [
                    RefsInputEndereco.RefInputCidade.current,
                    RefsInputEndereco.RefInputBairro.current,
                    RefsInputEndereco.RefInputRua.current,
                    RefsInputEndereco.RefInputUF.current
                ]
                inputs.forEach(input => {
                    input.style.border = "1px solid #ccc"
                })

                RefsInputEndereco.RefInputCidade.current.value = ''
                RefsInputEndereco.RefInputBairro.current.value = ''
                RefsInputEndereco.RefInputRua.current.value = ''
                RefInputCepTextResposta.current.textContent = "Cep não encontrado"
                setTimeout(() => {
                    RefInputCepTextResposta.current.textContent = ""
                }, 3000);
            }
        }



    }, [VerificaCEP])
    useEffect(() => {
        if (numero != "") {
            RefsInputEndereco.RefInputNumero.current.style.border = "1px solid yellowgreen"
            RefsIconsVerificacaoEndereco.Numero.current.style.color = "yellowgreen"
            RefsIconsVerificacaoEndereco.Numero.current.classList.add('bi-patch-check')
        } else {
            RefsInputEndereco.RefInputNumero.current.style.border = "1px solid #ccc"
            RefsIconsVerificacaoEndereco.Numero.current.classList.remove('bi-patch-check')

        }
    }, [numero])
    useEffect(() => {
        if (nomeAnuncioLength >= 1) {
            RefsInputEndereco.RefInputTitulo.current.style.border = "1px solid yellowgreen"
            RefsIconsVerificacaoEndereco.Titulo.current.style.color = "yellowgreen"
            RefsIconsVerificacaoEndereco.Titulo.current.classList.add('bi-patch-check')
        } else {
            RefsInputEndereco.RefInputTitulo.current.style.border = "1px solid #ccc"
            RefsIconsVerificacaoEndereco.Titulo.current.classList.remove('bi-patch-check')

        }
    }, [nomeAnuncioLength])

    // > Etapa 2 Fim


    // > Etapa 3 Inicio
    const [RecursosBasicosSelecionados, setRecursosBasicosSelecionados] = useState(new Set()) //Set Recursos Basicos Selecionados
    const Adiciona_Remove_ListaRecursosBasicos = (item) => {
        const NovoItem = new Set(RecursosBasicosSelecionados)
        if (NovoItem.has(item)) {
            NovoItem.delete(item)
        } else {
            NovoItem.add(item)
        }
        setRecursosBasicosSelecionados(NovoItem)
    }
    useEffect(() => {
        //console.log(RecursosBasicosSelecionados)
        setDadosNovoAnuncio(prev => ({
            ...prev, Recursos: { ...prev.Recursos, RecursosBasicos: RecursosBasicosSelecionados }
        }))

    }, [RecursosBasicosSelecionados])
    // > Etapa 3 Fim



    // > Etapa 4 Inicio | Recursos Especificos
    const [tipoSala, setTipoSala] = useState(""); // Pega o tipo da sala
    const [recursosEspecificos, setRecursosEspecificos] = useState([]); //Lista os recursos de acordo com a sala
    const [RecursosEspecificosSelecionados, setRecursosEspecificosSelecionados] = useState(new Set()); // recursos Especifico array

    useEffect(() => {
        setRecursosEspecificos(recursosPorSala[tipoSala] || []);
    }, [tipoSala]);

    const Adiciona_Remove_ListaRecursosEspecificos = (item) => {
        const novos = new Set(RecursosEspecificosSelecionados);
        if (novos.has(item)) {
            novos.delete(item);
        } else {
            novos.add(item);
        }
        setRecursosEspecificosSelecionados(novos);
        setDadosNovoAnuncio(prev => ({ ...prev, Recursos: { ...prev.Recursos, RecursosEspecificos: { ...prev.Recursos.RecursosEspecificos, Recursos: novos } } }))

    };
    // > Bloco 4 Fim


    //Bloco 4 Inicio | Horarios, Datas e Valor
    const [DataAtual, setDataAtual] = useState("")
    const ListHorarios = Array.from({ length: 23 }, (_, i) => {
        const hora = (i + 1).toString().padStart(2, "0")
        return `${hora}:00`
    })

    //Bloco 4 Fim




    useEffect(() => {

        if (etapaAtual === 2) {
            const campos = DadosNovoAnuncio.InfosBasicas;
            const algumVazio = Object.values(campos).some(campo => campo.trim() === "");
            if (algumVazio) {
                //console.log("Há campos vazios");
                setEtapa2_Preenchido(false)
            } else {
                //console.log("Todos os campos preenchidos");
                setEtapa2_Preenchido(true)
            }
        }

        if (DadosNovoAnuncio.Recursos.RecursosBasicos.size > 0) {
            setEtapa4_Preenchido(true)

        } else {
            setEtapa4_Preenchido(false)
        }

        if (DadosNovoAnuncio.Recursos.RecursosEspecificos.TipoSala != "" && DadosNovoAnuncio.Recursos.RecursosEspecificos.Recursos.size > 0) {
            setEtapa5_Preenchido(true)
        } else {
            setEtapa5_Preenchido(false)
        }

        if (DadosNovoAnuncio.Datas.Inicial != "" && DadosNovoAnuncio.Datas.Final != "" && DadosNovoAnuncio.Horarios.Abertura != "" && DadosNovoAnuncio.Horarios.Fechamento != "" && DadosNovoAnuncio.Valor != "") {
            setEtapa7_Preenchido(true)
        } else {
            setEtapa7_Preenchido(false)
        }

        if (DadosNovoAnuncio.Descricao != "" && DadosNovoAnuncio.Imagens.Imagem1 != "" && DadosNovoAnuncio.Imagens.Imagem2 != "" && DadosNovoAnuncio.Imagens.Imagem3 != "" && DadosNovoAnuncio.Imagens.Imagem4 != "" && DadosNovoAnuncio.Imagens.Imagem5 != "") {
            setEtapa9_Preenchido(true)
        } else {
            setEtapa9_Preenchido(false)
        }
        //console.log(DadosNovoAnuncio)
    }, [DadosNovoAnuncio]);

    useEffect(() => {
        if (Etapa2_Preenchido && Etapa4_Preenchido && Etapa5_Preenchido && Etapa7_Preenchido && Etapa9_Preenchido) {
            //console.log("Todas as áreas foram preenchidas")
            setEtapa_Todas_Preenchido(true)
        } else {
            //console.log("Há áreas que não foram preenchidas.")
            setEtapa_Todas_Preenchido(false)
        }
    }, [Etapa1_Preenchido, Etapa2_Preenchido, Etapa4_Preenchido, Etapa5_Preenchido, Etapa7_Preenchido, Etapa9_Preenchido])


    useEffect(() => {
        //console.log(etapaAtual)
        if (etapaAtual === 1) { //Infos
            RefBtnAvancar.current.disabled = false;
            RefBtnAvancar.current.style.opacity = "100%";
        }
        if (etapaAtual === 2) { // Titulo e endereço
            if (!Etapa2_Preenchido) {
                RefBtnAvancar.current.disabled = true;
                RefBtnAvancar.current.style.opacity = "50%";
            } else {
                RefBtnAvancar.current.disabled = false;
                RefBtnAvancar.current.style.opacity = "100%";
            }
        }
        if (etapaAtual === 3) { //Infos
            RefBtnAvancar.current.disabled = false;
            RefBtnAvancar.current.style.opacity = "100%";
        }
        if (etapaAtual === 4) { // Recuros Basicos
            if (!Etapa4_Preenchido) {
                RefBtnAvancar.current.disabled = true;
                RefBtnAvancar.current.style.opacity = "50%";
            } else {
                RefBtnAvancar.current.disabled = false;
                RefBtnAvancar.current.style.opacity = "100%";
            }
        }
        if (etapaAtual === 5) { // Recuros Especificos
            if (!Etapa5_Preenchido) {
                RefBtnAvancar.current.disabled = true;
                RefBtnAvancar.current.style.opacity = "50%";
            } else {
                RefBtnAvancar.current.disabled = false;
                RefBtnAvancar.current.style.opacity = "100%";
            }
        }
        if (etapaAtual === 6) { //Infos
            RefBtnAvancar.current.disabled = false;
            RefBtnAvancar.current.style.opacity = "100%";
        }
        if (etapaAtual === 7) { // Datas, Horarios e valores
            if (!Etapa7_Preenchido) {
                RefBtnAvancar.current.disabled = true;
                RefBtnAvancar.current.style.opacity = "50%";
            } else {
                RefBtnAvancar.current.disabled = false;
                RefBtnAvancar.current.style.opacity = "100%";
            }
        }
        if (etapaAtual === 8) { //Infos
            RefBtnAvancar.current.disabled = false;
            RefBtnAvancar.current.style.opacity = "100%";
        }
        if (etapaAtual === 9) { // Descrição e imagens
            if (!Etapa9_Preenchido) {
                RefBtnAvancar.current.disabled = true;
                RefBtnAvancar.current.style.opacity = "50%";
            } else {
                RefBtnAvancar.current.disabled = false;
                RefBtnAvancar.current.style.opacity = "100%";
            }
        }
    }, [etapaAtual, Etapa1_Preenchido, Etapa2_Preenchido, Etapa3_Preenchido, Etapa4_Preenchido, Etapa5_Preenchido, Etapa7_Preenchido, Etapa9_Preenchido])

    const RefInputCepTextResposta = useRef(null)
    const RefSelectValueHorario_Abertura = useRef(null)
    const RefSelectValueHorario_Fechamento = useRef(null)

    const RefInput01_image = useRef(null)

    //Btn Avançar
    const RefBtnAvancar = useRef(null)

    const [TextRespostaReq, setTextRespostaReq] = useState('')
    const RefTextResposta = useRef(null)
    const [ModoAguardandoResposta, setModoAguardandoResposta] = useState(false)
    const [LoadingSucesso, setLoadingSucesso] = useState(false)

    const [ContadorBarraProgresso, setContadorBarraProgresso] = useState(0)
    const [ValorReal, setValorReal] = useState(0)

    useEffect(() => {
        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        //console.log(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                            })

                    } else {
                        setStatusLogin(false)
                        navigate('/')
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)
            navigate('/')

        }

        const hoje = new Date()
        const ano = hoje.getFullYear();
        const mes = String(hoje.getMonth() + 1).padStart(2, "0")
        const dia = String(hoje.getDate() + 1).padStart(2, "0")
        //console.log(dia, mes, ano)
        setDataAtual(`${ano}-${mes}-${dia}`)

    }, [])


    const recursosPorSala = {
        Fisioterapia: [
            'Cama de Fisioterapia',
            'Equipamento de eletroterapia',
            'Equipamento de hidroterapia',
            'Equipamento de termoterapia',
            'Mesa de massagem',
            'Aparelho de laser',
        ],
        Odontologia: [
            'Cadeira odontológica',
            'Aparelho de raio-x',
            'Sucção',
            'Refletor',
            'Fotopolimerizador',
            'Mocho',
            'Autoclave',
        ],
        Oftalmologista: [
            'Cadeira e coluna oftalmológica',
            'Lupas e espelhos',
            'Armários e bancadas para organização',
            'Tabela de Snellen',
            'Lensômetro',
        ],
        Psicologia: [
            'Sala de atendimento individual',
            'Sala de atendimento em grupo',
            'Mesa de trabalho',
            'Cadeiras confortáveis',
            'Iluminação suave',
        ],
    };



    return (
        <>
            <Header02 InfosUser={InfosUser} StatusLogin={StatusLogin} />
            <main className="Page_criar_anuncio" style={{ opacity: ModoAguardandoResposta ? "70%" : "100%", pointerEvents: ModoAguardandoResposta ? "none" : "auto" }} >

                <section className="etapa_1 boxslide" style={{ display: etapaAtual === 1 ? "flex" : "none" }}>
                    <div className="Boxslide_content">
                        <div className="box_textEtapa">
                            <p className="Etapa_1_Left_text_1">Etapa 1</p>
                            <p className="Etapa_1_Left_text_2">Comece com as informações básicas do seu espaço</p>
                            <p className="Etapa_1_Left_text_3">Nesta etapa, vamos reunir os dados essenciais sobre a sua acomodação. Informe o nome do anúncio e os detalhes de localização para que os futuros interessados possam encontrar seu espaço com facilidade. Esses dados são importantes para facilitar a busca e garantir que sua propriedade seja exibida corretamente para as pessoas interessadas.</p>
                        </div>
                        <div className="box_imgEtapa">
                            <img className="imgEtapa" src={ImagemEpaço1} alt="" />
                        </div>
                    </div>
                </section>


                <section className="etapa_2 boxslide " style={{ display: etapaAtual === 2 ? "flex" : "none" }}>
                    <div className="Boxslide_content etapaFuncional">
                        <h2>Informe o título do anúncio e o endereço do seu espaço.</h2>

                        <div className="Inputs_content">
                            <input ref={RefsInputEndereco.RefInputTitulo} autocomplete="off" type="text" maxLength={50} className="inputs_page titulo_input" name="nomeAnuncio" placeholder="Nome do seu anúncio" required
                                onChange={(e) => { setDadosNovoAnuncio(prev => ({ ...prev, InfosBasicas: { ...prev.InfosBasicas, Titulo: e.target.value } })), setnomeAnuncioLength(e.target.value.length) }} />
                            <p style={{ color: nomeAnuncioLength >= 50 ? 'red' : 'black', opacity: nomeAnuncioLength >= 1 ? "100%" : "0%" }} className="InputsTextSuporte">{nomeAnuncioLength}/50</p>
                            <i ref={RefsIconsVerificacaoEndereco.Titulo} class="IconsInputVerifica bi "></i>
                        </div>


                        <div className="Duo_Inputs_content">
                            <div className="BoxInput">
                                <input autocomplete="off" ref={RefsInputEndereco.RefInputCEP} type="text" inputMode="numeric" pattern="\d{8}" maxLength={8} className="inputs_page" name="cep" placeholder="Cep"
                                    onChange={(e) => { PegaCep(e.target.value) }} required />
                                <p ref={RefInputCepTextResposta} className="InputCepTextResposta"></p>
                                <i ref={RefsIconsVerificacaoEndereco.Cep} class="IconsInputVerifica bi "></i>
                            </div>

                            <div className="BoxInput">
                                <input ref={RefsInputEndereco.RefInputCidade} type="text" className="inputs_page pointevent_none" name="cidade" placeholder="Cidade" required />
                                <i ref={RefsIconsVerificacaoEndereco.Cidade} class="IconsInputVerifica bi "></i>
                            </div>
                        </div>

                        <div className="Duo_Inputs_content">
                            <div className="BoxInput">
                                <input ref={RefsInputEndereco.RefInputBairro} type="text" className="inputs_page pointevent_none" name="bairro" placeholder="Bairro" required />
                                <i ref={RefsIconsVerificacaoEndereco.Bairro} class="IconsInputVerifica bi "></i>
                            </div>

                            <div className="Duo_BoxInput">
                                <div className="BoxInput">
                                    <input ref={RefsInputEndereco.RefInputUF} type="text" className="inputs_page pointevent_none" name="uf" placeholder="UF" required />
                                    <i ref={RefsIconsVerificacaoEndereco.Uf} class="IconsInputVerifica bi "></i>
                                </div>
                                <div className="BoxInput">
                                    <input ref={RefsInputEndereco.RefInputNumero} type="number" className="inputs_page" name="numero" placeholder="Nº" required
                                        onChange={(e) => { setDadosNovoAnuncio(prev => ({ ...prev, InfosBasicas: { ...prev.InfosBasicas, Numero: e.target.value } })); setNumero(e.target.value) }} />
                                    <i ref={RefsIconsVerificacaoEndereco.Numero} class="IconsInputVerifica bi "></i>
                                </div>
                            </div>
                        </div>


                        <div className="Inputs_content pointevent_none">
                            <input ref={RefsInputEndereco.RefInputRua} type="text" className="inputs_page" name="rua" placeholder="Rua" required />
                            <i ref={RefsIconsVerificacaoEndereco.Rua} class="IconsInputVerifica bi"></i>
                        </div>
                    </div>
                </section>

                <section className="etapa_3 boxslide" style={{ display: etapaAtual === 3 ? "flex" : "none" }}>
                    <div className="Boxslide_content">
                        <div className="box_textEtapa">
                            <p className="Etapa_1_Left_text_1">Etapa 2</p>
                            <p className="Etapa_1_Left_text_2">Escolha os recursos disponíveis no seu espaço</p>
                            <p className="Etapa_1_Left_text_3">Agora que já informamos os dados básicos, vamos destacar os recursos que sua acomodação oferece. Esses itens são fundamentais para atrair profissionais que buscam um espaço adequado às suas necessidades e também ajudam os usuários a comparar opções com mais clareza.</p>
                        </div>
                        <div className="box_imgEtapa">
                            <img className="imgEtapa" src={ImagemEpaço1} alt="" />
                        </div>
                    </div>
                </section>


                <section className="etapa_4 boxslide" style={{ display: etapaAtual === 4 ? "flex" : "none" }}>
                    <h2>Recursos básicos</h2>
                    <div className="main-box-btns">
                        {['Wi-fi', 'Estacionamento', 'Ar-condicionado', 'Recepção', 'Elevador', 'Banheiro'].map((item) => (
                            <button
                                key={item}
                                className={`btn_recursos ${RecursosBasicosSelecionados.has(item) ? 'selected' : ''}`}
                                onClick={() => Adiciona_Remove_ListaRecursosBasicos(item)}
                            >
                                <span>{item}</span>
                            </button>
                        ))}
                    </div>
                </section>

                <section className="etapa_5 boxslide" style={{ display: etapaAtual === 5 ? "flex" : "none" }}>
                    <h2>Que tipo de sala você oferece?</h2>
                    <select className="little-2" value={tipoSala}
                        onChange={(e) => (setDadosNovoAnuncio(prev => ({ ...prev, Recursos: { ...prev.Recursos, RecursosEspecificos: { ...prev.Recursos.RecursosEspecificos, TipoSala: e.target.value } } })), setTipoSala(e.target.value))}>
                        <option value="">Selecione o tipo da sala</option>
                        <option value="Fisioterapia">Fisioterapia</option>
                        <option value="Odontologia">Odontologia</option>
                        <option value="Oftalmologista">Oftalmologista</option>
                        <option value="Psicologia">Psicologia</option>

                    </select>

                    <div className="main-box-btns">
                        {recursosEspecificos.map((item, i) => (
                            <button
                                key={i}
                                className={`btn_recursos ${RecursosEspecificosSelecionados.has(item) ? 'selected' : ''}`}
                                onClick={() => Adiciona_Remove_ListaRecursosEspecificos(item)}
                            >
                                <span>{item}</span>
                            </button>
                        ))}
                    </div>
                </section>


                <section className="etapa_6 boxslide" style={{ display: etapaAtual === 6 ? "flex" : "none" }}>
                    <div className="Boxslide_content">
                        <div className="box_textEtapa">
                            <p className="Etapa_1_Left_text_1">Etapa 3</p>
                            <p className="Etapa_1_Left_text_2">Defina a disponibilidade e o valor do seu espaço</p>
                            <p className="Etapa_1_Left_text_3">Nesta etapa, você definirá quando o seu espaço estará disponível e quanto será cobrado pelo uso. Essas informações são essenciais para que os profissionais possam planejar suas reservas com facilidade e segurança.</p>
                        </div>
                        <div className="box_imgEtapa">
                            <img className="imgEtapa" src={ImagemEpaço1} alt="" />
                        </div>
                    </div>
                </section>

                <section className="etapa_7 boxslide" style={{ display: etapaAtual === 7 ? "flex" : "none" }}>
                    <h2>Data, horário de funcionamento e valor por dia</h2>
                    <div className="box-data">

                        <div className="Box_Inputs_grupo">
                            <span>Quando o espaço estará disponível?</span>
                            <div className="Box_Options_Select_Entrada_Saida">
                                <input type="date" className="Box_Inputs_grupo_inputs" name="inicio" required min={DataAtual}
                                    onChange={(e) => setDadosNovoAnuncio(prev => ({ ...prev, Datas: { ...prev.Datas, Inicial: e.target.value } }))} />
                                <span>até</span>
                                <input type="date" className="Box_Inputs_grupo_inputs" name="fim" required min={DadosNovoAnuncio.Datas.Inicial} style={{ opacity: DadosNovoAnuncio.Datas.Inicial ? "100%" : "40%", pointerEvents: DadosNovoAnuncio.Datas.Inicial ? "auto" : "none" }}
                                    onChange={(e) => setDadosNovoAnuncio(prev => ({ ...prev, Datas: { ...prev.Datas, Final: e.target.value } }))} />
                            </div>
                        </div>

                        <div className="Box_Inputs_grupo">

                            <span>Em quais horários?</span>
                            <div className="Box_Options_Select_Entrada_Saida">
                                <select required ref={RefSelectValueHorario_Abertura} className="select_Option_Horarios" name="OptionAbertura" id=""
                                    onChange={(e) => { setDadosNovoAnuncio(prev => ({ ...prev, Horarios: { ...prev.Horarios, Abertura: e.target.value } })) }}>
                                    <option value="">ABERTURA</option>
                                    {
                                        ListHorarios.map((item, index) => {
                                            return (
                                                <option key={index} value={item}> {item} </option>
                                            )
                                        })
                                    }

                                </select>

                                <span>até</span>
                                <select required ref={RefSelectValueHorario_Fechamento} className="select_Option_Horarios" name="OptionFechamento" id="" style={{ opacity: DadosNovoAnuncio.Horarios.Abertura ? "100%" : "40%", pointerEvents: DadosNovoAnuncio.Horarios.Abertura ? "auto" : "none" }}
                                    onChange={(e) => { setDadosNovoAnuncio(prev => ({ ...prev, Horarios: { ...prev.Horarios, Fechamento: e.target.value } })) }} >

                                    <option value="">ENCERRAMENTO</option>
                                    {
                                        ListHorarios.map((item, index) => {
                                            return (
                                                <option key={index} value={item} style={{ display: parseInt(item) < parseInt(DadosNovoAnuncio.Horarios.Abertura) + 1 ? "none" : "flex" }}> {item} </option>
                                            )
                                        })
                                    }

                                </select>
                            </div>

                        </div>

                        <div className="valorAnuncioBox">
                            <span>Valor por dia: R$</span>
                            <input
                                type="text"
                                value={ValorReal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                onChange={e => {
                                    const numero = Number(e.target.value.replace(/\D/g, '')) / 100;
                                    setValorReal(numero);
                                    setDadosNovoAnuncio(prev => ({ ...prev, Valor: numero }));
                                }}
                            />                        </div>

                    </div>
                </section>

                <section className="etapa_8 boxslide" style={{ display: etapaAtual === 8 ? "flex" : "none" }}>
                    <div className="Boxslide_content">
                        <div className="box_textEtapa">
                            <p className="Etapa_1_Left_text_1">Etapa 4</p>
                            <p className="Etapa_1_Left_text_2">Adicione uma descrição atrativa e boas imagens do seu espaço
                            </p>
                            <p className="Etapa_1_Left_text_3">Agora é o momento de apresentar seu espaço da melhor forma possível. Uma boa descrição e imagens de qualidade são fundamentais para chamar a atenção dos profissionais e transmitir confiança logo no primeiro contato com o seu anúncio.</p>
                        </div>
                        <div className="box_imgEtapa">
                            <img className="imgEtapa" src={ImagemEpaço1} alt="" />
                        </div>
                    </div>
                </section>

                <section className="etapa_9 boxslide" style={{ display: etapaAtual === 9 ? "flex" : "none" }}>
                    <h2>Faça uma descrição e anexe algumas fotos</h2>

                    <div className="text-content">
                        <span>Descrição do anúncio</span>
                        <textarea required name="descricao" id=""
                            onChange={(e) => setDadosNovoAnuncio(prev => ({ ...prev, Descricao: e.target.value }))} ></textarea >
                    </div>

                    <div className="Photos-content">
                        <span>Adicione algumas fotos</span>
                        <div class="box-upload" >

                            <div class="upload-container" >
                                <div className="Content_Upload" style={{ backgroundImage: DadosNovoAnuncio.Imagens.Imagem1 ? `url(${URL.createObjectURL(DadosNovoAnuncio.Imagens.Imagem1)})` : `` }}>
                                    <input required ref={RefInput01_image} type="file" id="upload-input-1" accept="image/*"
                                        onChange={(e) => setDadosNovoAnuncio(prev => ({ ...prev, Imagens: { ...prev.Imagens, Imagem1: e.target.files[0] } }))} />

                                    <label style={{ opacity: DadosNovoAnuncio.Imagens.Imagem1 ? "0%" : "100%" }} for="upload-input-1" class="upload-label">
                                        <span>Upload de Foto</span>
                                        <i class="bi bi-upload"></i>
                                    </label>
                                </div>
                            </div>

                            <div class="upload-container">
                                <div className="Content_Upload" style={{ backgroundImage: DadosNovoAnuncio.Imagens.Imagem2 ? `url(${URL.createObjectURL(DadosNovoAnuncio.Imagens.Imagem2)})` : `` }}>
                                    <input required type="file" id="upload-input-2" accept="image/*"
                                        onChange={(e) => setDadosNovoAnuncio(prev => ({ ...prev, Imagens: { ...prev.Imagens, Imagem2: e.target.files[0] } }))} />
                                    <label style={{ opacity: DadosNovoAnuncio.Imagens.Imagem2 ? "0%" : "100%" }} for="upload-input-2" class="upload-label">
                                        <span>Upload de Foto</span>
                                        <i class="bi bi-upload"></i>
                                    </label>
                                </div>
                            </div>

                            <div class="upload-container">
                                <div className="Content_Upload" style={{ backgroundImage: DadosNovoAnuncio.Imagens.Imagem3 ? `url(${URL.createObjectURL(DadosNovoAnuncio.Imagens.Imagem3)})` : `` }}>
                                    <input required type="file" id="upload-input-3" accept="image/*"
                                        onChange={(e) => setDadosNovoAnuncio(prev => ({ ...prev, Imagens: { ...prev.Imagens, Imagem3: e.target.files[0] } }))} />
                                    <label style={{ opacity: DadosNovoAnuncio.Imagens.Imagem3 ? "0%" : "100%" }} for="upload-input-3" class="upload-label">
                                        <span>Upload de Foto</span>
                                        <i class="bi bi-upload"></i>
                                    </label>
                                </div>
                            </div>

                            <div class="upload-container">
                                <div className="Content_Upload" style={{ backgroundImage: DadosNovoAnuncio.Imagens.Imagem4 ? `url(${URL.createObjectURL(DadosNovoAnuncio.Imagens.Imagem4)})` : `` }}>
                                    <input required type="file" id="upload-input-4" accept="image/*"
                                        onChange={(e) => setDadosNovoAnuncio(prev => ({ ...prev, Imagens: { ...prev.Imagens, Imagem4: e.target.files[0] } }))} />
                                    <label style={{ opacity: DadosNovoAnuncio.Imagens.Imagem4 ? "0%" : "100%" }} for="upload-input-4" class="upload-label">
                                        <span>Upload de Foto</span>
                                        <i class="bi bi-upload"></i>
                                    </label>
                                </div>
                            </div>

                            <div class="upload-container">
                                <div className="Content_Upload" style={{ backgroundImage: DadosNovoAnuncio.Imagens.Imagem5 ? `url(${URL.createObjectURL(DadosNovoAnuncio.Imagens.Imagem5)})` : `` }}>
                                    <input required type="file" id="upload-input-5" accept="image/*"
                                        onChange={(e) => setDadosNovoAnuncio(prev => ({ ...prev, Imagens: { ...prev.Imagens, Imagem5: e.target.files[0] } }))} />
                                    <label style={{ opacity: DadosNovoAnuncio.Imagens.Imagem5 ? "0%" : "100%" }} for="upload-input-5" class="upload-label">
                                        <span >Upload de Foto</span>
                                        <i class="bi bi-upload"></i>
                                    </label>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>


                <div className="box_buttons">
                    <div className="Barra_progresso">
                        <div className="Progresso" style={{ width: `${ContadorBarraProgresso}%` }}>

                        </div>
                    </div>

                    <div className="Grande_Box_Button">
                        <div className="Button_Content">
                            <button onClick={voltar} className="Button_form btn_back" style={{ opacity: etapaAtual === 1 ? "0%" : "100%" }} disabled={etapaAtual === 1}>
                                Voltar
                            </button>
                        </div>


                        <div className="Button_Content">
                            <div className="TextResposta">
                                <p ref={RefTextResposta} >{TextRespostaReq} </p>
                                <Loading01 display={LoadingSucesso} />
                            </div>

                            <div className="btn_bo">
                                <button ref={RefBtnAvancar} onClick={avancar} className="Button_form btn_advance" >
                                    {ModoAguardandoResposta ? "" : "Avançar"}
                                </button>
                                <div className="BoxLoading" style={{ display: ModoAguardandoResposta ? "flex" : "none" }}>
                                    <Loading01 display={true} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </>
    );

    function TextRespostaStyle(Estado) {
        if (Estado === "Positivo") {
            RefTextResposta.current.style.display = "flex"
            RefTextResposta.current.style.color = "yellowgreen"

        }
        if (Estado === "Negativo") {
            RefTextResposta.current.style.display = "flex"
            RefTextResposta.current.style.color = "red"

            setTimeout(() => {
                RefTextResposta.current.style.display = "none"
                clearTimeout()
            }, 2000);
        }
    }

    function PegaCep(CepValue) {
        if (CepValue && CepValue.length === 8) {
            axios.get(`https://viacep.com.br/ws/${CepValue}/json/`)
                .then((resposta) => {
                    if (resposta.data) {
                        if (resposta.data['erro'] === "true") {
                            setVerificaCEP(false)
                            RefsInputEndereco.RefInputCidade.current.value = ''
                            RefsInputEndereco.RefInputBairro.current.value = ''
                            RefsInputEndereco.RefInputRua.current.value = ''
                            RefsInputEndereco.RefInputUF.current.value = ''
                            //console.log(resposta.data)
                        } else {
                            setVerificaCEP(true)
                            RefInputCepTextResposta.current.textContent = ""
                            RefsInputEndereco.RefInputCidade.current.value = resposta.data.localidade
                            RefsInputEndereco.RefInputBairro.current.value = resposta.data.bairro
                            RefsInputEndereco.RefInputRua.current.value = resposta.data.logradouro
                            RefsInputEndereco.RefInputUF.current.value = resposta.data.uf
                            setDadosNovoAnuncio(prev => ({
                                ...prev, InfosBasicas:
                                    { ...prev.InfosBasicas, Cep: CepValue, Cidade: resposta.data.localidade, Bairro: resposta.data.bairro, Rua: resposta.data.logradouro, Uf: resposta.data.uf }
                            }))
                            //console.log(resposta.data)

                        }


                    } else {
                        console.log("Não foi possivel puxar os dados do cep")
                        console.log(resposta.data)
                    }
                })
        }
    }

    function CriarAnuncio(event) {
        event.preventDefault()

        const DadosAnuncioNovo = new FormData()
        DadosAnuncioNovo.append('id_usuario', InfosUser.id_usuario)
        DadosAnuncioNovo.append('nomeAnuncio', DadosNovoAnuncio.InfosBasicas.Titulo)
        DadosAnuncioNovo.append('cep', DadosNovoAnuncio.InfosBasicas.Cep)
        DadosAnuncioNovo.append('cidade', DadosNovoAnuncio.InfosBasicas.Cidade)
        DadosAnuncioNovo.append('bairro', DadosNovoAnuncio.InfosBasicas.Bairro)
        DadosAnuncioNovo.append('rua', DadosNovoAnuncio.InfosBasicas.Rua)
        DadosAnuncioNovo.append('numero', DadosNovoAnuncio.InfosBasicas.Numero)

        DadosAnuncioNovo.append('RecursosBasicos', [...DadosNovoAnuncio.Recursos.RecursosBasicos])
        DadosAnuncioNovo.append('TipoSala', DadosNovoAnuncio.Recursos.RecursosEspecificos.TipoSala)
        DadosAnuncioNovo.append('RecursosEspecificos', [...DadosNovoAnuncio.Recursos.RecursosEspecificos.Recursos])

        DadosAnuncioNovo.append('DataInicial', DadosNovoAnuncio.Datas.Inicial)
        DadosAnuncioNovo.append('DataFinal', DadosNovoAnuncio.Datas.Final)
        DadosAnuncioNovo.append('HorarioAbertura', DadosNovoAnuncio.Horarios.Abertura)
        DadosAnuncioNovo.append('HorarioFechamento', DadosNovoAnuncio.Horarios.Fechamento)
        DadosAnuncioNovo.append('valor', DadosNovoAnuncio.Valor)

        DadosAnuncioNovo.append('descricao', DadosNovoAnuncio.Descricao)
        DadosAnuncioNovo.append('files', DadosNovoAnuncio.Imagens.Imagem1)
        DadosAnuncioNovo.append('files', DadosNovoAnuncio.Imagens.Imagem2)
        DadosAnuncioNovo.append('files', DadosNovoAnuncio.Imagens.Imagem3)
        DadosAnuncioNovo.append('files', DadosNovoAnuncio.Imagens.Imagem4)
        DadosAnuncioNovo.append('files', DadosNovoAnuncio.Imagens.Imagem5)

        setModoAguardandoResposta(true)
        axios.post(`${BaseUrl.url}/anuncio/criarAnuncio`, DadosAnuncioNovo)
            .then(resposta => {
                if (resposta.data['sucesso']) {
                    setModoAguardandoResposta(false)
                    TextRespostaStyle("Positivo")
                    setLoadingSucesso(true)
                    console.log(resposta.data)
                    setTextRespostaReq(`${resposta.data['Mensagem1']}. Redirecionando... `)
                    RefBtnAvancar.current.style.display = "none"
                    setContadorBarraProgresso(100)
                    setTimeout(() => {
                        navigate("/meus-anuncios")
                    }, 4000);

                } else {
                    setModoAguardandoResposta(false)
                    TextRespostaStyle("Negativo")
                    console.log("Algo deu errado")
                    console.log(resposta.data)
                    setTextRespostaReq(resposta.data['Mensagem1'])
                }
            })
            .catch(error => {
                console.log(error)
            })

    }


}

export default NovoAnuncioPage
