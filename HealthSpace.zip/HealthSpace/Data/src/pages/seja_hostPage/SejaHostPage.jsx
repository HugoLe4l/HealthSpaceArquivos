import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import axios from "axios"
import { Link } from "react-router-dom"
import "./SejaHostPage.css"

//Components
import Header02 from "../../components/Header02/header02.jsx"
import Footer02 from "../../components/Footer02/footer02.jsx"

//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao.js";

//Icons e imagens
import header_logo from "../../../public/Assets/Interface/header-logo.png"
import Image1 from "../../../public/Assets/Interface/Image1.png"

function SejaHostPage() {
    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(false)
    const navigate = useNavigate()

    useEffect(() => {
        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        //console.log(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                            })

                    } else {
                        setStatusLogin(false)
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)

        }
    }, [])

    return (
        <>

            <Header02 InfosUser={InfosUser} StatusLogin={StatusLogin} />

            <main className="Page_PreNovoANuncio">
                <section className="Section1_Titulo">
                    <img src={header_logo} alt="Logo" />
                    <h2>Anuncie seu espaço no HealthSpace</h2>
                </section>

                <section className="InfosPqAnunciar">
                    <div className="PagePre_Left">

                        <section className="Sectioon2_Text">
                            <h3>Por que anunciar na HealthSpace?</h3>
                            <div className="Text_Pergunta">
                                <h4><i class="bi bi-check-lg"></i> Renda extra sem complicação</h4>
                                <p>Cadastre seu espaço em poucos passos e comece a ganhar dinheiro com horários ociosos — sem burocracia.</p>
                            </div>
                            <hr className="line752" />
                            <div className="Text_Pergunta">
                                <h4><i class="bi bi-check-lg"></i> Flexibilidade total</h4>
                                <p>Está usando o espaço só em alguns dias? Sem problema! Você escolhe quando ele estará disponível para reservas.</p>
                            </div>
                            <hr className="line752" />
                            <div className="Text_Pergunta">
                                <h4><i class="bi bi-check-lg"></i> Você no controle</h4>
                                <p>Defina preços, horários disponíveis e as regras de uso do seu espaço. O controle é todo seu.</p>
                            </div>
                            <hr className="line752" />
                            <div className="Text_Pergunta">
                                <h4><i class="bi bi-check-lg"></i> Gestão simples e centralizada</h4>
                                <p>Veja todas as reservas, pagamentos e mensagens num só lugar. Tudo direto pela plataforma.</p>
                            </div>
                            <hr className="line752" />


                        </section>
                    </div>

                    <div className="PagePre_Right">
                        <img src={Image1} alt="" />
                    </div>

                </section>
                {StatusLogin ? (
                    <Link to={'/criar-anuncio'} className="Btn_ContinuarPagePre">Eu quero começar a anunciar</Link>
                ) : (
                    <div className="Box_deve_fazer_login Btn_ContinuarPagePre">
                        <p>Faça <a onClick={() => navigate('/login')}>LOGIN</a> ou <a onClick={() => navigate('/cadastro')}>CRIE UMA CONTA</a> e comece a monetizar o seu espaço!</p>
                    </div>
                )}

            </main>

            <Footer02 />
        </>
    )
}

export default SejaHostPage