import { useParams, useNavigate, data } from "react-router-dom"
import { useState, useEffect, useRef } from "react"
import axios from "axios"
import "./anuncios.css"

import AvatarUsuario from "../../../public/Assets/Imagens/user.jpg"
import NotFoundImage from "../../../public/Assets/Imagens/Not_Image_Card.jpg"
//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao"

//Components
import Header02 from "../../components/Header02/header02"
import Footer02 from "../../components/Footer02/footer02"

import Flatpickr from "react-flatpickr";
import "flatpickr/dist/themes/material_blue.css"; // ou outro tema
import { Portuguese } from "flatpickr/dist/l10n/pt.js";




function AnunciosPage() {
    const { CodigoProduto } = useParams()
    const [DadosAnuncio, setDadosAnuncio] = useState([])

    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    //const navigate = useNavigate()
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(true)

    const [datas, setDatas] = useState([]);


    const navigate = useNavigate()



    const [Button_Em_Requisicao, setButton_Em_Requisicao] = useState(false)

    const RefInputDateFlatpickr = useRef(null)

    useEffect(() => {
        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        //console.log(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                            })

                    } else {

                        setStatusLogin(false)
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)
        }


    }, [])

    useEffect(() => {
        axios.post(`${BaseUrl.url}/anuncio/anuncioInfo`, { CodigoProduto })
            .then((resposta) => {

                if (resposta.data['QuantResultados']) {
                    setDadosAnuncio(resposta.data['Dados'][0]);
                    console.log(resposta.data)
                }else{
                    //navigate("/")
                }

            })
            .catch((err) => console.error("Erro ao buscar anúncio:", err));
    }, [CodigoProduto]); // Só roda quando o código muda


    useEffect(() => {

        if (datas.length > 0) {
            setButton_Em_Requisicao(true)
            console.log(datas)

        } else {
            console.log("Defina um horario de Entrada e Saida")
            setButton_Em_Requisicao(false)

        }

    }, [datas])
    const [DatasDisponiveis, setDatasDisponiveis] = useState([])
    useEffect(() => {
        const ds = DadosAnuncio?.Datas_Disponiveis
            ? DadosAnuncio.Datas_Disponiveis.split(",").map(data => data.trim())
            : [];
        setDatasDisponiveis(ds);
    }, [DadosAnuncio]);
    return (
        <>
            <Header02 InfosUser={InfosUser} StatusLogin={StatusLogin} />
            <main className="Page_Anuncio">
                <div className="TituloAnuncio">
                    <h1 className="TituloAnuncio">{DadosAnuncio.nome} <strong className="CodigoStyleId">#{DadosAnuncio.id}</strong></h1>
                    <div className="ShareFavBox">
                        <div className="ShareFavBoxStyle">
                            <i class="bi bi-box-arrow-up"></i> <p>Compartilhar</p>
                        </div>
                        <div className="ShareFavBoxStyle">
                            <i class="bi bi-heart"></i> <p>Salvar</p>
                        </div>
                    </div>
                </div>
                <div className="Box_Imagens_Anuncio">
                    <div className="Box_Imagens_Anuncio_Left" style={{ backgroundImage: DadosAnuncio.Url_imagem_1 ? `url(https://drive.google.com/thumbnail?id=${DadosAnuncio.Url_imagem_1}&sz=w1000)` : NotFoundImage }}>
                    </div>
                    <div className="Box_Imagens_Anuncio_Right">

                        <div className="rowAnuncioImagem">
                            <div className="ImagemAnuncioConjunto" style={{ backgroundImage: DadosAnuncio.Url_imagem_2 ? `url(https://drive.google.com/thumbnail?id=${DadosAnuncio.Url_imagem_2}&sz=w1000)` : NotFoundImage }} id="ImagemAnuncio02"></div>
                            <div className="ImagemAnuncioConjunto rightborder" id="ImagemAnuncio03" style={{ backgroundImage: DadosAnuncio.Url_imagem_3 ? `url(https://drive.google.com/thumbnail?id=${DadosAnuncio.Url_imagem_3}&sz=w1000)` : NotFoundImage }}></div>
                        </div>

                        <div className="rowAnuncioImagem">
                            <div className="ImagemAnuncioConjunto" id="ImagemAnuncio04" style={{ backgroundImage: DadosAnuncio.Url_imagem_4 ? `url(https://drive.google.com/thumbnail?id=${DadosAnuncio.Url_imagem_4}&sz=w1000)` : NotFoundImage }} ></div>
                            <div className="ImagemAnuncioConjunto rightborder" id="ImagemAnuncio05" style={{ backgroundImage: DadosAnuncio.Url_imagem_5 ? `url(https://drive.google.com/thumbnail?id=${DadosAnuncio.Url_imagem_5}&sz=w1000)` : NotFoundImage }}></div>
                        </div>

                    </div>

                </div>

                <hr className="linha01" />


                <section className="SectionAnuncio_01">
                    <div className="AboutAnuncio">
                        <h2 >Um pouco sobre o espaço</h2>

                        <p>{DadosAnuncio.descricao}</p>

                    </div>
                    <div className="BoxLocAnuncio">
                        <div className="LocAnuncioCidade">
                            <i class="bi bi-geo-alt-fill"></i> <p>{DadosAnuncio.bairro}, {DadosAnuncio.cidade}</p>
                        </div>
                        |
                        <p>{DadosAnuncio.rua} n°{DadosAnuncio.numero},  {DadosAnuncio.cep?.slice(0, 5) + "-" + DadosAnuncio.cep?.slice(5)}</p>

                    </div>

                    <div className="FeddBackAnuncio">
                        <div className="RatingBox">
                            <i class="bi bi-star-fill"></i> <p>{DadosAnuncio.rating}</p>
                        </div>
                        <p id="RatingAnuncio">75 comentaríos</p>
                    </div>

                </section>

                <section className="SectionAnuncio_02">
                    <hr className="hr2" />
                    <div class="advertiser-perfil">

                        <img class="adveriser-image-perfil" src={AvatarUsuario} alt="AvatarUsuario" />

                        <div class="adveriser-infos">
                            <p class="text-Pertence">Pertence a: <a href="#">{DadosAnuncio.nome_usuario}</a></p>
                            <p class="text-age">1 ano na plataforma</p>
                        </div>
                    </div>
                    <hr className="hr2" />
                </section>

                <section className="SectionAnuncio_03">
                    <div class="tags-announcement">
                        <h3>Alguns recursos que o proprietário oferece</h3>
                        <div class="tags-field">
                            <div class="tag">
                                <i class="bi bi-ev-front"></i>
                                <p>Estacionamento incluído</p>
                            </div>
                            <div class="tag">
                                <i class="bi bi-wifi"></i>
                                <p>Recepção</p>
                            </div>
                            <div class="tag">
                                <i class="bi bi-wifi"></i>
                                <p>Banheiro</p>
                            </div>
                            <div class="tag">
                                <i class="bi bi-wifi"></i>
                                <p>Elevador</p>
                            </div>
                            <div class="tag">
                                <i class="bi bi-wifi"></i>
                                <p>Wi-Fi</p>
                            </div>
                            <div class="tag">
                                <i class="bi bi-wifi"></i>
                                <p>Ar-condicionado</p>
                            </div>

                        </div>
                        <a id="btn-mostrar-todas-comodidades" href="#">Mostrar todas as 14 comodidades</a>
                    </div>
                </section>

                <section className="SectionAnuncio_04">


                    <div className="Box_Reserva_Content">
                        <p id="PriceAnuncio"> <strong>R$ {parseFloat(DadosAnuncio.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong> /dia</p>

                        <div className="Horarios">
                            <i class="bi bi-alarm"></i>
                            <p>Funcionando das {DadosAnuncio?.HorarioAbertura?.slice(0, 5)} áte {DadosAnuncio?.HorarioFechamento?.slice(0, 5)}</p>
                        </div>

                        <div className="Box_InputDateFlatpickr">
                            <p>Adicione datas</p>

                            <div className="Box_InputDateFlatpickr_Input">
                                <i class="bi bi-calendar-plus" onClick={() => { RefInputDateFlatpickr.current.flatpickr.open(); }}></i>
                                <Flatpickr className="FlatPickr_input"
                                    ref={RefInputDateFlatpickr}
                                    options={{
                                        mode: "multiple",
                                        dateFormat: "Y-m-d",
                                        locale: Portuguese, // precisa importar também o idioma se quiser traduzir
                                        enable: DatasDisponiveis
                                    }}

                                    value={datas}
                                    onChange={setDatas}

                                />
                            </div>

                        </div>

                        <div className="Box_InputDateSelecionados">
                            <p>Selecionados:</p>
                            <div className="Box_InputDateSelecionados_row">

                                {datas.map((item, index) => { return (<p key={index}>{item.toISOString().split('T')[0].split('-').reverse().join('/')}</p>) })}

                            </div>
                        </div>



                    </div>





                    <button className="Btn_Reservar_Box" onClick={() => navigate(`/reserva/${DadosAnuncio.id}`, { state: { datas } })} style={{ pointerEvents: Button_Em_Requisicao ? "auto" : "none", opacity: Button_Em_Requisicao ? "100%" : "30%" }}>Reservar</button>
                    <div className="Box_Reserva_Content">

                        <p className="text_Box_Reserva_Content">Você ainda não será cobrado</p>

                        <div className="TabelaFinalPrice">
                            <div className="TabelaFinalPrice_Row">
                                <p>R${parseFloat(DadosAnuncio.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} x {datas.length} dias</p>
                                <p>R${parseFloat(DadosAnuncio.valor * datas.length).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                            </div>
                            <div className="TabelaFinalPrice_Row">
                                <p>Taxa de serviço HelthSpace</p>
                                <p>R$ 0</p>
                            </div>
                        </div>

                        <hr className="linha02" />

                        <div className="Price_Total">
                            <p>Preço total</p>
                            <p>R${parseFloat(DadosAnuncio.valor * datas.length).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                        </div>
                    </div>
                </section>
            </main>

            <Footer02 />
        </>
    )
}

export default AnunciosPage