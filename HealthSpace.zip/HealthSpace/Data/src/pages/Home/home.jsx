import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"

import axios from "axios";
import "./home.css"

import Card01 from "../../components/Card 01/card01";

//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao";

//Components
import Header03 from "../../components/Header03/header03"
import Footer02 from "../../components/Footer02/footer02";

//Icons e Imagens
import GatoTriste2 from "../../../public/Assets/Icons/GatoTriste2.png"
import Frame3 from "../../../public/Assets/Imagens/Frame 3.png"



function HomePage() {
    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    const navigate = useNavigate()
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(true)
    const [AnuncioHomeList, setAnuncioHomeList] = useState([])
    const [TemAnuncio, setTemAnuncio] = useState()

    const [CidadeDoUsuario, setCidadeDoUsuario] = useState("")
    const [PreferenciaTipoSalaDoUsuario, setPreferenciaTipoSalaDoUsuario] = useState("Fisioterapia")


    useEffect(() => {
        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        //console.log(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                            })

                    } else {
                        setStatusLogin(false)
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)

        }

        axios.get(`${BaseUrl.url}/anuncio/listDisponivel`)
            .then(resposta => {
                if (resposta.data['TemAnuncios']) {
                    //console.log(resposta.data['resultado'])
                    setAnuncioHomeList(resposta.data['resultado'])
                    setTemAnuncio(true)
                } else {
                    setTemAnuncio(false)
                }

            })

        axios.get("https://ipwho.is/")
            .then(resposta => {
                setCidadeDoUsuario(resposta.data.city)
            })
    }, [])



    return (
        <>
            <Header03 InfosUser={InfosUser} StatusLogin={StatusLogin} />
            <main className="Page_Home_Main">

                <section className="Page_Home_Banner">
                    <img src={Frame3} alt="" />
                </section>

                <hr className="BorderBlue" />
                <p className="Btn_Pesquisa_Avancada" onClick={() => navigate('/encontrar-anuncio')}>Pesquisa avançada</p>

                {TemAnuncio ? (
                    <>
                        {PreferenciaTipoSalaDoUsuario != "" && (
                            <section className="SectionStyle Section01_Page_Home">
                                <div className="Page_Home_Main_Titulo">
                                    <p>Espaços em {CidadeDoUsuario} com base nas suas preferências</p>
                                    <p className="Btn_PageHomeVermais" onClick={() => navigate(`/encontrar-anuncio?Cidade=${CidadeDoUsuario}&TipoSala=${PreferenciaTipoSalaDoUsuario}`)}>Ver mais</p>
                                </div>


                                <div className="Box_Cards_Home">
                                    {
                                        AnuncioHomeList.filter(anuncio => anuncio.cidade === CidadeDoUsuario).filter(anuncio => anuncio.TipoSala === `${PreferenciaTipoSalaDoUsuario}`).slice(0, 6).map((anuncio, index) => {
                                            console.log(anuncio)

                                            return (
                                                <Card01 key={index} anuncio={[anuncio]} />
                                            )
                                        })
                                    }


                                </div>
                            </section>
                        )}



                        { /* Filtro por Cidade */}
                        <section className="SectionStyle Section02_Page_Home">
                            <div className="Page_Home_Main_Titulo">
                                <p>Espaços em {CidadeDoUsuario}</p>
                                <p className="Btn_PageHomeVermais" onClick={() => navigate(`/encontrar-anuncio?Cidade=${CidadeDoUsuario}`)}>Ver mais</p>
                            </div>


                            <div className="Box_Cards_Home">
                                {
                                    AnuncioHomeList.filter(anuncio => anuncio.cidade === CidadeDoUsuario).slice(0, 6).map((anuncio, index) => {
                                        return (
                                            <Card01 key={index} anuncio={[anuncio]} />
                                        )
                                    })
                                }


                            </div>
                        </section>

                        <section className="SectionStyle Section03_Page_Home">
                            <div className="Page_Home_Main_Titulo">
                                <p>Escolha o espaço ideal para atender com conforto e praticidade.</p>
                            </div>

                            <div className="Box_Cards_Home">
                                {
                                    AnuncioHomeList.map((anuncio, index) => {
                                        //console.log(anuncio)

                                        return (
                                            <Card01 key={index} anuncio={[anuncio]} />
                                        )
                                    })
                                }


                            </div>
                        </section>
                    </>
                ) : (
                    <div className="AvisoAnuncios">
                        <img src={GatoTriste2} alt="" />
                        <p>Infelizmente, não encontramos nenhum anúncio disponível. :(</p>

                    </div>
                )}





            </main >

            <Footer02 />

        </>
    )
}

export default HomePage
