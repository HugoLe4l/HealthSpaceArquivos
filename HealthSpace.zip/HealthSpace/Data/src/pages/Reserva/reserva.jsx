import "./reserva.css"

import axios from "axios"

import { useParams, useLocation, useNavigate } from "react-router-dom"

import { useState, useEffect, useRef } from "react"

//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao.js"

//Components
import Header02 from "../../components/Header02/header02.jsx"
import Footer02 from "../../components/Footer02/footer02.jsx"
import Loading01 from "../../components/Loading01/loading01.jsx"

//Icones
import Coins_icon from "../../../public/Assets/Icons/Coloridos/Coins_icon.png"
import Pix_icon from "../../../public/Assets/Icons/Coloridos/Pix_icon.png"

import Not_Image_Card from "../../../public/Assets/Imagens/Not_Image_Card.jpg"

function ReservaPage() {
    const location = useLocation();
    const navigate = useNavigate();

    const { CodigoProduto } = useParams()
    const [DadosAnuncio, setDadosAnuncio] = useState([])


    const { datas } = location.state || {};

    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    const [IdUsuario, setIdUsuario] = useState()
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(true)

    const [EstadoOptionsPayout, setEstadoOptionsPayout] = useState(false)
    const [MetodoPayoutSelecionado, setMetodoPayoutSelecionado] = useState("Coins")

    const Ref_OptionsPayout = useRef(null)


    const [QuantDias, setQuantDias] = useState(datas && datas.length > 0 ? datas.length : 1);


    const [Button_Em_Requisicao, setButton_Em_Requisicao] = useState(false)
    const [Texto_de_Resultado_Requisicao, setTexto_de_Resultado_Requisicao] = useState('')
    const [Requisicao_sucesso, setRequisicao_sucesso] = useState(false)
    const [ShowTextoResultadoRequisicao, setShowTextoResultadoRequisicao] = useState(false)
    const Ref_Btn_Reservar_Box = useRef(null)

    const [ArrayDatas, setArrayDatas] = useState([])

    useEffect(() => {
        if (datas && datas.length > 0) {
            const datasFormatadas = datas.map(item =>
                item.toISOString().split('T')[0].split('-').join('-')
            );
            setArrayDatas(datasFormatadas);
        }
    }, [datas]);

    useEffect(() => {
        console.log("----------");
        console.log(ArrayDatas)
        console.log("----------");

    }, [ArrayDatas])


    useEffect(() => {
        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        setIdUsuario(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                            })

                    } else {

                        setStatusLogin(false)
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)
        }


    }, [])

    useEffect(() => {
        axios.post(`${BaseUrl.url}/anuncio/anuncioInfo`, { CodigoProduto })
            .then((resposta) => {
                setDadosAnuncio(resposta.data['Dados'][0]);
                console.log(resposta.data['Dados'][0])
                //console.log(`ID: ${CodigoProduto} CARREGADO`)

            })
            .catch((err) => console.error("Erro ao buscar anúncio:", err));
    }, [CodigoProduto]); // Só roda quando o código muda

    return (
        <>

            <Header02 InfosUser={InfosUser} StatusLogin={StatusLogin} />

            <main id="FinalizarReservaMain">
                <div id="box_finalizar_reserva">
                    <section class="section_left_reserva">
                        <div class="tittle_reserva">

                            <h3>Confirmar e pagar</h3>
                        </div>

                        <div class="dados_reserva">
                            <h5>Sua reserva</h5>
                            <div class="box_infos_reserva">
                                <div class="left_box_reserva">
                                    <h6>Data</h6>
                                    <div className="Box_InputDateSelecionados_row">

                                        {datas?.map((item, index) => { return (<p key={index}>{item.toISOString().split('T')[0].split('-').reverse().join('/')}</p>) })}

                                    </div>
                                </div>
                                <h4>Editar</h4>
                            </div>
                            <div class="box_infos_reserva">
                                <div class="left_box_reserva">
                                    <h6>Horário</h6>
                                    <div className="Horarios">
                                        <i class="bi bi-alarm"></i>
                                        <p>Funcionando das {DadosAnuncio?.HorarioAbertura?.slice(0, 5)} áte {DadosAnuncio?.HorarioFechamento?.slice(0, 5)}</p>
                                    </div>
                                </div>
                            </div>
                            <hr id="hr" />
                        </div>

                    </section>

                    <section class="section_right_reserva">
                        <div class="card_reserva">
                            <div class="reserva_anuncio_dados">
                                <div class="image_reserva" style={{ backgroundImage: DadosAnuncio.Url_imagem_1 ? `url(https://drive.google.com/thumbnail?id=${DadosAnuncio.Url_imagem_1})` : `url(${Not_Image_Card})` }} ></div>
                                <div class="info_reserva_detalhes">
                                    <h3>{DadosAnuncio.nome} <strong className="cod_anuncio1">#{DadosAnuncio.id}</strong></h3>
                                    <p>Anunciado por {DadosAnuncio.nome_usuario}</p>
                                    <div class="rating-box">
                                        <i class="bi bi-star-fill"></i>
                                        <p class="rating-info">{DadosAnuncio.rating}</p>
                                        <p>(0 Avaliações)</p>
                                    </div>
                                </div>
                            </div>
                            <hr id="hr" />
                            <h6>Informações de preço</h6>
                            <div>
                                <div class="row_info_reserva">
                                    <p>R$ {parseFloat(DadosAnuncio?.valor)?.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} x {QuantDias} dias</p>
                                    <p>R$ {parseFloat(DadosAnuncio?.valor * QuantDias)?.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                                </div>
                                <div class="row_info_reserva">
                                    <p>Taxa extra</p>
                                    <p>R$ 0</p>
                                </div>

                            </div>
                            <hr id="hr" />
                            <div class="row_info_reserva">
                                <h6>Total (BRL)</h6>
                                <h6>R$ {parseFloat(DadosAnuncio?.valor * QuantDias)?.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h6>
                            </div>

                        </div>

                    </section>
                </div>




                <div id="Box_Payout_Metodo" style={{ display: StatusLogin ? "flex" : "none" }}>
                    <div className="box_options_payout" >
                        <p id="textPagarCom">Pagar com</p>
                        <div className="select_options" onClick={() => { setEstadoOptionsPayout(!EstadoOptionsPayout) }}>
                            <p><img src={`../../../public/Assets/Icons/Coloridos/${MetodoPayoutSelecionado}_icon.png`} alt="" />{MetodoPayoutSelecionado}</p>
                            <i class="bi bi-chevron-down"></i>
                        </div>
                        <ul ref={Ref_OptionsPayout} className="optionsPayout" style={{ height: EstadoOptionsPayout ? "121px" : "0px" }}>
                            <li onClick={() => { setMetodoPayoutSelecionado("Pix"); setEstadoOptionsPayout(false) }}>
                                <input type="radio" name="radioOptionsPayout" value="Pix" checked={MetodoPayoutSelecionado === "Pix"} />
                                <div className="box_method_pay"><img src={Pix_icon} alt="" />Pix</div>
                            </li>
                            <hr />
                            <li onClick={() => { setMetodoPayoutSelecionado("Coins"); setEstadoOptionsPayout(false) }}>
                                <input type="radio" name="radioOptionsPayout" value="Coins" checked={MetodoPayoutSelecionado === "Coins"} />
                                <div className="box_method_pay"><img src={Coins_icon} alt="" />Coins</div>
                            </li>
                        </ul>
                    </div>

                    <div className="Box_Button_Finalizar_Reserva" >
                        <div className="TextoResultadoRequisicao" style={{display: ShowTextoResultadoRequisicao ? "flex" : "none", color: Requisicao_sucesso ? "yellowgreen" : "red"}}>
                            <p >{Texto_de_Resultado_Requisicao}</p>
                            <div className="loading_btn" style={{display: Requisicao_sucesso ? "flex" : "none"}}>
                                <Loading01 display="flex" />
                            </div>
                        </div>


                        <div ref={Ref_Btn_Reservar_Box} className="Btn_Reservar_Box" onClick={() => { FinalizarReserva(MetodoPayoutSelecionado, IdUsuario, DadosAnuncio.id, QuantDias, ArrayDatas) }} style={{ pointerEvents: Button_Em_Requisicao ? "none" : "auto", opacity: Button_Em_Requisicao ? "50%" : "100%" }}>
                            <p style={{ opacity: Button_Em_Requisicao ? "0%" : "100%" }}>Finalizar reserva</p>
                            <div className="loading_btn" style={{ opacity: Button_Em_Requisicao ? "100%" : "0%" }}>
                                <Loading01 display="flex" />
                            </div>
                        </div>
                    </div>

                    <p id="textMetodoDePagamentoAlert" style={{ display: MetodoPayoutSelecionado === "Pix" ? "Flex" : "none" }}>O método de pagamento PIX está indisponível no momento.</p>
                </div>

                <div id="loginbox" style={{ display: StatusLogin ? "none" : "grid" }}>
                    <p> Faça o <strong onClick={() => { navigate("/login") }}>LOGIN</strong> ou <strong onClick={() => { navigate("/cadastro") }}>REGISTRE-SE</strong> para continuar </p>
                </div>


            </main>
            <Footer02 />

        </>
    )


    function FinalizarReserva(MetodoPayoutSelecionado, IdUsuario, idAnuncio, QuantDias, ArrayDatas) {
        setButton_Em_Requisicao(true)
        console.log("Metodo: " + MetodoPayoutSelecionado)
        console.log("IdUser: " + IdUsuario)
        console.log("IdAnuncio: " + idAnuncio)
        console.log("QuantDias: " + QuantDias)
        console.log("Entrada: " + ArrayDatas)

        axios.post(`${BaseUrl.url}/anuncio/pagamento`, { MetodoPayoutSelecionado, IdUsuario, idAnuncio, QuantDias, ArrayDatas })

            .then((resposta => {
                if (resposta.data['sucesso']) {
                    setButton_Em_Requisicao(true)
                    setTexto_de_Resultado_Requisicao(resposta.data['Mensagem1'])
                    setRequisicao_sucesso(true)
                    setShowTextoResultadoRequisicao(true)
                    Ref_Btn_Reservar_Box.current.style.display = "none"
                    console.log(resposta.data)
                    setTimeout(() => {
                         navigate("/MinhasReservas")
                    }, 6000);

                } else {
                    setButton_Em_Requisicao(false)
                    setTexto_de_Resultado_Requisicao(resposta.data['Mensagem1'])
                    setRequisicao_sucesso(false)
                    setShowTextoResultadoRequisicao(true)
                    setTimeout(() => {
                        setShowTextoResultadoRequisicao(false)
                        clearTimeout()
                    }, 3000);
                    console.log(resposta.data)
                }


            }))
            .catch((err) => console.error("Erro ao realizar pagamento:", err));


    }


}

export default ReservaPage