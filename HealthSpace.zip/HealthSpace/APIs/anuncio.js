import { Router } from "express";
import { connection } from "./conexao.js";
import stream from "stream";
import { google } from "googleapis";
import multer from "multer";
import { v4 as uuidv4 } from 'uuid';


const router = Router()
const upload = multer()

router.get("/listDisponivel", (req, resp) => {
    const { mainTag } = req.body

    let sqlQuery = "SELECT a.*, GROUP_CONCAT(d.Data_Disponivel SEPARATOR ', ') AS Datas_Disponiveis FROM anuncios a JOIN datas d ON a.id = d.id_anuncio WHERE d.status=(?) GROUP BY a.id"
    let parametro = ["Disponivel"]

    if (mainTag) {
        sqlQuery += " AND mainTag=(?)"
        parametro.push(mainTag)
    }

    connection.query(
        sqlQuery, parametro,

        (err, resultado) => {
            //console.log(resultado)
            if (err) {
                resp.json({
                    Mensagem1: "Error ao realizar consulta"
                })
            } else {
                if (resultado.length > 0) {
                    resp.json({
                        Mensagem1: `Exibindo todos os resultados de anuncios ativos e com tags ${parametro}`,
                        resultado: resultado,
                        TemAnuncios: true

                    })
                } else {
                    resp.json({
                        Mensagem1: `Não tem anuncios disponiveis`,
                        resultado: resultado,
                        TemAnuncios: false
                    })
                }


            }
        }
    )


})

router.post("/anuncioInfo", (req, resp) => {
    const { CodigoProduto } = req.body
    let AntigaSql = "SELECT a.*, GROUP_CONCAT(d.Data_Disponivel SEPARATOR ', ') AS Datas_Disponiveis FROM anuncios a JOIN datas d ON a.id = d.id_anuncio WHERE a.id = (?) AND d.status = (?) GROUP BY a.id"

    connection.query(
        "SELECT a.*, GROUP_CONCAT(d.Data_Disponivel SEPARATOR ', ') AS Datas_Disponiveis FROM anuncios a LEFT JOIN datas d ON a.id = d.id_anuncio AND d.status =(?) WHERE a.id =(?) GROUP BY a.id"
        , ["Disponivel",CodigoProduto],

        (err, resultado) => {

            if (err) {
                resp.json({
                    Mensagem1: "Error ao realizar consulta"
                })
            } else {
                if (resultado.length > 0) {
                    resp.json({
                        Mensagem1: `Sucesso ao realizar consulta de anuncio com id ${CodigoProduto}`,
                        Dados: resultado,
                        QuantResultados: resultado.length
                    })
                    console.log(`Sucesso ao realizar consulta de anuncio com id ${CodigoProduto}`);

                } else {
                    resp.json({
                        Mensagem1: `Nada encontrado ou Sem reserva disponivel na consulta de anuncio com id ${CodigoProduto}`,
                        Dados: resultado,
                        QuantResultados: resultado.length
                    })
                    console.log(`Nada encontrado ou Sem reserva disponivel na consulta de anuncio com id ${CodigoProduto}`)
                }

            }

        }
    )
})

router.post("/reservas-confirmadas", async (req, resp) => {
    const { id_usuario } = req.body

    connection.query(
        "SELECT DISTINCT a.* FROM reservas_confirmadas rc JOIN anuncios a ON rc.id_anuncio = a.id WHERE rc.id_reservante = (?)", [id_usuario], async (err, ResultAnuncios) => {
            if (err) {
                resp.json({
                    Mensagem1: "Houve um erro ao consultar as reservas"
                })
            } else {
                if (ResultAnuncios.length > 0) {
                    connection.query("SELECT * FROM reservas_confirmadas WHERE id_reservante =(?)", [id_usuario], (err, ResultReservas) => {
                        if (err) {
                            resp.json({
                                Mensagem1: "Houve um erro ao consultar as reservas"
                            })
                        } else {

                            const MeusAnunciosConfirmados = ResultAnuncios.map(anuncio => {
                                const reservasRelacionadas = ResultReservas.filter(reserva => reserva.id_anuncio === anuncio.id);

                                
                                const reservasAgrupadasPorCodigo = reservasRelacionadas.reduce((acc, reserva) => {
                                    const codigo = reserva.Codigo_reserva;

                                    if (!acc[codigo]) {
                                        acc[codigo] = {
                                            Codigo_reserva: codigo,
                                            ValorPago: reserva.ValorPago,
                                            datas: []
                                        };
                                    }

                                    acc[codigo].datas.push(reserva.Data_Reservada);

                                    return acc;
                                }, {});

                                
                                const reservasFormatadas = Object.values(reservasAgrupadasPorCodigo);

                                return {
                                    anuncio: anuncio,
                                    reservas: reservasFormatadas
                                };
                            });



                            resp.json({
                                Mensagem1: `Resultado de reservas confirmadas do usuario com id ${id_usuario}.`,
                                AnunciosEncontrados: true,
                                ResultAnuncios: ResultAnuncios,
                                ResultReservas: ResultReservas,
                                MeusAnunciosConfirmados: MeusAnunciosConfirmados
                            })
                        }
                    })




                } else {
                    resp.json({
                        Mensagem1: "Consulta realizada, nao foi encontrado nada reservado por esse id",
                        AnunciosEncontrados: false
                    })
                }

            }
        }
    )

})

router.post("/pagamento", (req, resp) => {
    const { MetodoPayoutSelecionado, IdUsuario, idAnuncio, QuantDias, ArrayDatas } = req.body
    const codigoReserva = `${IdUsuario}-${idAnuncio}-${uuidv4()}`

    let PermicaoPagamento = false
    console.log(ArrayDatas)
    if (MetodoPayoutSelecionado === "Coins") {

        let UsuarioEncontrado = false
        let AnuncioEncontrado = false
        let TemCoins = false
        let AnuncioDisponibulidade = false
        PermicaoPagamento = true



        connection.query(
            "SELECT * FROM usuarios Where id_usuario =(?)", [IdUsuario], (err, resultado) => { //VERIFICA SE USUARIO EXISTE
                if (err) {
                    resp.json({
                        Mensagem1: "Error ao Fazer Requisição"
                    })
                } else {
                    if (resultado.length > 0) { //Usuario encontrado

                        UsuarioEncontrado = true
                        let UsuarioDados = []
                        UsuarioDados.push(resultado[0].nome)
                        UsuarioDados.push(resultado[0].HCoins)

                        connection.query(
                            "SELECT * FROM anuncios Where id =(?)", [idAnuncio], (err, resultado) => { //VERIFICA SE ANUNCIO EXISTE
                                if (err) {
                                    resp.json({
                                        Mensagem1: "Error ao Fazer Requisição"
                                    })
                                } else {

                                    if (resultado.length > 0) { // Verifica se o anuncio existe

                                        AnuncioEncontrado = true
                                        let AnuncioDados = []
                                        AnuncioDados.push(resultado[0].id)
                                        AnuncioDados.push(resultado[0].nome)
                                        AnuncioDados.push(resultado[0].valor)

                                        //console.log(UsuarioDados)
                                        //console.log(AnuncioDados)

                                        if (UsuarioDados[1] >= (AnuncioDados[2] * QuantDias)) { // Verifica se usuario tem HCoins maior que O valor final
                                            TemCoins = true
                                            let ContaFinal = UsuarioDados[1] - (AnuncioDados[2] * QuantDias)


                                            const Verifica_Se_Existe_Reserva_Promise = ArrayDatas.map(item => {
                                                return new Promise((resolve, reject) => {
                                                    connection.query(
                                                        "SELECT * FROM reservas_confirmadas WHERE id_anuncio=(?) AND Data_Reservada =(?)", [AnuncioDados[0], item], (err, result) => {
                                                            if (err) {
                                                                reject(err);
                                                            } else {
                                                                resolve(result);
                                                            }
                                                        }
                                                    );
                                                });
                                            });

                                            Promise.all(Verifica_Se_Existe_Reserva_Promise)
                                                .then(results => {
                                                    const algumaDataExiste = results.some(result => result.length > 0);
                                                    if (algumaDataExiste) {
                                                        resp.json({
                                                            Mensagem1: "Uma ou mais datas já foram reservadas.",
                                                            sucesso: false
                                                        })

                                                    } else {
                                                        const UpdateDatasStatus = ArrayDatas.map(item => {
                                                            return new Promise((resolve, reject) => {
                                                                connection.query(
                                                                    "UPDATE datas SET Status = ? WHERE Data_Disponivel = ?",
                                                                    ["Reservado", item],
                                                                    (err, resultadoUpdate) => {
                                                                        if (err) {
                                                                            return reject(err);
                                                                        }

                                                                        connection.query(
                                                                            "INSERT INTO reservas_Confirmadas (id_anuncio, id_reservante, Data_Reservada, ValorPago, Codigo_reserva) VALUES (?, ?, ?, ?, ?)",
                                                                            [AnuncioDados[0], IdUsuario, item, AnuncioDados[2] * QuantDias, codigoReserva],
                                                                            (err, resultadoInsert) => {
                                                                                if (err) {
                                                                                    return reject(err);
                                                                                }
                                                                                resolve(resultadoInsert);
                                                                            }
                                                                        );
                                                                    }
                                                                );
                                                            });
                                                        });
                                                        Promise.all(UpdateDatasStatus)
                                                            .then(resposta => {

                                                                connection.query("UPDATE usuarios SET HCoins =(?) WHERE id_usuario =(?)", [ContaFinal, IdUsuario], (err, resultado) => {
                                                                    if (err) {
                                                                        console.error("Erro ao atualizar HCoins:", err);
                                                                        return resp.status(500).json({
                                                                            sucesso: false,
                                                                            mensagem: "Erro ao atualizar HCoins"
                                                                        });
                                                                    } else {

                                                                        resp.json({
                                                                            Mensagem1: "Pagamento concluído com sucesso. Você será redirecionado em instantes.",
                                                                            sucesso: true,
                                                                            resposta: resposta,
                                                                            ArrayDatas: ArrayDatas
                                                                        })

                                                                    }
                                                                })
                                                            })

                                                    }
                                                })







                                        } else { // Se não possuir
                                            resp.json({
                                                TemCoins: TemCoins,
                                                Mensagem1: "Você não possui HCOINS o suficiente",
                                                ArrayDatas: ArrayDatas

                                            })
                                        }

                                    } else {
                                        resp.json({
                                            AnuncioEncontrado: AnuncioEncontrado,
                                            Mensagem1: "Produto não encontrado"
                                        })
                                    }

                                }
                            }
                        )




                    } else { // Usuario não encontrado pela Id fornecida
                        resp.json({
                            UsuarioEncontrado: UsuarioEncontrado,
                            Mensagem1: `Usuario com id (${IdUsuario} não foi encontrado)`
                        })
                    }
                }
            }


        )








    } else if (MetodoPayoutSelecionado === "Pix") {
        resp.json({
            PermicaoPagamento: PermicaoPagamento,
            Mensagem1: "Operação com Pix não disponivel"
        })
    } else {
        resp.json({
            PermicaoPagamento: PermicaoPagamento,
            Mensagem1: "Invalido Tipo de Pagamento",
            TipoPagamento: MetodoPayoutSelecionado
        })
    }


})

router.post("/criarAnuncio", upload.array('files', 5), async (req, resp) => {
    const DadosAnuncioNovo = req.body
    const files = req.files;
    //console.log(DadosAnuncioNovo)
    console.log(files)
    // id_usuario, nome_usuario, nomeAnuncio, cidade, bairro, rua, numero, cep, descricao, valor, HorarioAbertura, HorarioFechamento . 
    // Depois adicionar: Imagem01, Imagem02, Imagem03, Imagem04, Imagem05.

    const RecursosBasicos = JSON.stringify(DadosAnuncioNovo.RecursosBasicos.split(',').map(item => item.trim()));
    const RecursosEspecificos = JSON.stringify(DadosAnuncioNovo.RecursosEspecificos.split(',').map(item => item.trim()));

    function CriarDatas(DataInicial, DataFinal) {
        const inicio = new Date(`${DataInicial}T00:00:00`);
        const fim = new Date(`${DataFinal}T00:00:00`);

        const datas = [];
        let contador = 0;

        while (inicio <= fim) {
            contador++;
            const dataFormatada = inicio.toISOString().split("T")[0]; // YYYY-MM-DD
            datas.push(`${dataFormatada}=${contador}`);
            inicio.setDate(inicio.getDate() + 1);
        }

        return datas;
    }


    // Teste da função com datas fornecidas
    const ArrayDatas = CriarDatas(DadosAnuncioNovo.DataInicial, DadosAnuncioNovo.DataFinal);
    //console.log(ArrayDatas);


    let nomeUsuario = 'xxxx'
    connection.query('SELECT * FROM usuarios WHERE id_usuario=(?)', [DadosAnuncioNovo.id_usuario], async (err, resultadoInfosUser) => {
        if (err) {

        } else {
            if (resultadoInfosUser.length > 0) {
                //onsole.log(resultadoInfosUser)
                nomeUsuario = resultadoInfosUser[0].nome
                //console.log(nomeUsuario)

                // Verifica se a objetos vazios no Array recebido DadosAnuncioNovo
                let ArrayTodoCompleto = false
                if (Object.values(DadosAnuncioNovo).every(valor => valor)) { // Se nenhum objeto do DadosAnuncioNovo esá vazio continua
                    ArrayTodoCompleto = true

                    if (files) {
                        const uploadIdsFile = []
                        //console.log('Arquivo enviado:', files);

                        const GOOGLE_API_FOLDER_ID = '1XAmV9PTmlp4Y8fqi87QXWYjO59TMRXK7';
                        try {
                            const auth = new google.auth.GoogleAuth({
                                keyFile: './ChaveGoogleDrive.json',
                                scopes: ['https://www.googleapis.com/auth/drive']
                            });

                            const driveService = google.drive({
                                version: 'v3',
                                auth
                            });



                            for (const file of files) {

                                const fileMetaData = {
                                    name: `user ${DadosAnuncioNovo.id_usuario} - ${file.originalname}`,
                                    parents: [GOOGLE_API_FOLDER_ID]
                                };

                                const bufferStream = new stream.PassThrough();
                                bufferStream.end(file.buffer);

                                const media = {
                                    mimeType: `${file.mimetype}`,
                                    body: bufferStream
                                };

                                const response = await driveService.files.create({
                                    resource: fileMetaData,
                                    media: media,
                                    fields: 'id'
                                });
                                uploadIdsFile.push(response.data.id)
                            }


                        } catch (err) {
                            console.log('Upload file error', err);
                        }

                        connection.query(
                            "INSERT INTO anuncios ( id_usuario, nome_usuario, nome, cidade, bairro, rua, numero, cep, descricao, DataInicial, DataFinal, valor, HorarioAbertura, HorarioFechamento, TipoSala, RecursosBasicos, RecursosEspecificos,  Url_imagem_1, Url_imagem_2, Url_imagem_3, Url_imagem_4, Url_imagem_5 ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?)",
                            [DadosAnuncioNovo.id_usuario,
                                nomeUsuario,
                            DadosAnuncioNovo.nomeAnuncio,
                            DadosAnuncioNovo.cidade,
                            DadosAnuncioNovo.bairro,
                            DadosAnuncioNovo.rua,
                            DadosAnuncioNovo.numero,
                            DadosAnuncioNovo.cep,
                            DadosAnuncioNovo.descricao,

                            DadosAnuncioNovo.DataInicial,
                            DadosAnuncioNovo.DataFinal,

                            DadosAnuncioNovo.valor,
                            DadosAnuncioNovo.HorarioAbertura,
                            DadosAnuncioNovo.HorarioFechamento,
                            DadosAnuncioNovo.TipoSala,
                                RecursosBasicos,
                                RecursosEspecificos,

                            uploadIdsFile[0],
                            uploadIdsFile[1],
                            uploadIdsFile[2],
                            uploadIdsFile[3],
                            uploadIdsFile[4]

                            ], (err, resultado) => {
                                if (err) {
                                    resp.json({
                                        Mensagem1: "Houve um erro ao tentar criar anúncio",
                                        error: err,
                                        DadosAnuncioNovo: DadosAnuncioNovo,
                                        filesImage: files,
                                        uploadIdsFile: uploadIdsFile
                                    })
                                    //console.log(RecursosBasicos)
                                } else {

                                    const InseriDatasReservas = ArrayDatas.map(item => {
                                        return new Promise((resolve, reject) => {
                                            connection.query("INSERT INTO datas (id_anuncio, Data_Disponivel) VALUES( ?, ?) ", [resultado.insertId, item], (err, resultado) => {

                                                if (err) {
                                                    reject(err)
                                                } else {
                                                    resolve(resultado)
                                                }

                                            })
                                        })
                                    })

                                    Promise.all(InseriDatasReservas)
                                        .then(resposta => {
                                            resp.json({
                                                Mensagem1: "Anúncio criado com sucesso",
                                                DadosAnuncioNovo: DadosAnuncioNovo,
                                                sucesso: true,
                                                ArrayDatas: ArrayDatas,
                                                resultado: resultado

                                            })
                                        })

                                        .catch(err => {
                                            console.error("Error ao criar anuncio")
                                            resp.status(500).json({
                                                sucesso: false,
                                                mensagem: "Erro ao inserir datas",
                                                erro: err
                                            });
                                        })
                                }
                            }
                        )



                    } else {
                        resp.json({
                            mensagem: 'Nenhum arquivo foi enviado',
                            resultado: "formData",
                        });
                    }






                } else { // Se algum objeto no Array DadosAnuncioNovo está vazio
                    resp.json({
                        Mensagem1: "Objetos vazios no Array DadosAnuncios",
                        DadosAnuncioNovo: DadosAnuncioNovo,
                        sucesso: false

                    })
                }
            } else {
                resp.json({
                    Mensagem1: "Usuario não encontrado",
                    DadosAnuncioNovo: DadosAnuncioNovo,
                    sucesso: false

                })

                //console.log("Usuario não encontrado")

            }
        }
    }
    )




})

router.post("/lista-meus-anuncios", (req, resp) => {
    const { id } = req.body

    connection.query('SELECT * FROM anuncios WHERE id_usuario=(?)', [id], (err, resultado) => {
        if (err) {

        } else {
            resp.json({
                Mensagem1: "Sucesso ao obter anuncios",
                Resultado: resultado
            })
        }
    })
})

export default router
