import "./Card_Avaliacao.css"

import Aval1 from "../../../public/Assets/Imagens/ava1.jpg"

function Card_Avaliacao() {
    return (
        <div className="Card_Avaliacao">

            <div className="User_Avaliador">
                <div className="User_Photo" style={{ backgroundImage: `url(${Aval1})` }}></div>
                <p>Arthur</p>
            </div>

            <div className="Box_Rating">
                <div className="Rating_Star_Box">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star"></i>
                    <i class="bi bi-star"></i>
                </div>
                <p>1 semana</p>
            </div>

            <div className="Box_Comentario">
                "Excelente sala, top demais"
            </div>
        </div>
    )
}

export default Card_Avaliacao