// src/components/SwiperCarousel.jsx
import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import { useNavigate } from "react-router-dom"

// Estilos obrigatórios
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

import Banner01 from "../../../public/Assets/Imagens/Banner01.png";
import Banner02 from "../../../public/Assets/Imagens/Banner02.png";
import Banner03 from "../../../public/Assets/Imagens/Banner03.png";


const SwiperCarousel = () => {

  const navigate = useNavigate()
  
  return (
    <Swiper
      modules={[Navigation, Pagination, Autoplay]} // Ativando os módulos
      navigation // Ativa os botões "next" e "prev"
      pagination={{ clickable: true }} // Ativa os dots
      autoplay={{ delay: 8000 }}
      loop={true}
      style={{ maxWidth: "100%", margin: "0 auto" }}
      speed={1000}
    >
      <SwiperSlide>
        <img onClick={() => navigate("/encontrar-anuncio")} src={Banner01} alt="Banner 1" style={{ width: "100%", height: "auto", cursor: "pointer" }} />
      </SwiperSlide>
      <SwiperSlide>
        <img onClick={() => navigate("/sejaHostPage")} src={Banner02} alt="Banner 2" style={{ width: "100%", height: "auto", cursor: "pointer" }} />
      </SwiperSlide>
      <SwiperSlide>
        <img onClick={() => navigate("/")} src={Banner03} alt="Banner 3" style={{ width: "100%", height: "auto", cursor: "pointer" }} />
      </SwiperSlide>
    </Swiper>
  );
};

export default SwiperCarousel;
