import "./RangeSlider.css"
import { useEffect, useState } from "react";
import { Range } from "react-range";
import "./RangeSlider.css"; // Importando o arquivo CSS

const STEP = 1;
const MIN = 1;
const MAX = 1001;

function RangeSlider( { onChange }) {
  const [values, setValues] = useState([1, 1001]);

  useEffect(() => {
    if(onChange) {
      onChange(values)
    }
  },[values])

  return (
    <div className="range-slider-container">
      <div className="range-slider-wrapper">

        <div className="range-values">
          <p>Preços</p>
          <div className="Valores">
            <span>R$: {values[0]}</span>
            -
            <span>{values[1] === 1001 ? "Ilimitado" : `R$: ${values[1]}`}</span>
          </div>
        </div>

        <Range
          values={values}
          step={STEP}
          min={MIN}
          max={MAX}
          onChange={setValues}
          renderTrack={({ props, children }) => (
            <div {...props} className="range-track">
              <div className="range-track-filled" style={{
                left: `${(values[0] / MAX) * 100}%`,
                width: `${((values[1] - values[0]) / MAX) * 100}%`
              }} />
              {children}
            </div>
          )}
          renderThumb={({ props }) => (
            <div {...props} className="range-thumb" />
          )}
        />

      </div>
    </div>
  );
}

export default RangeSlider;
