import "./card02.css"

import Image_Not_Found from "../../../public/Assets/Imagens/Not_Image_Card.jpg"


function Card02({ dadosAnuncio }) {

    console.log(dadosAnuncio.anuncio.Url_imagem_1 )
    return (
        <div className="Card_02">
            <div className="ImagemPrincipal" style={{backgroundImage : dadosAnuncio.anuncio.Url_imagem_1  ? `url(https://drive.google.com/thumbnail?id=${dadosAnuncio.anuncio.Url_imagem_1})` :  `url(${Image_Not_Found})`}}>

            </div>
            <div className="Card_Content">
                <div className="Card02_row1">
                    <h2>{dadosAnuncio.anuncio.nome} <strong className="codigoAnuncioStyle">#{dadosAnuncio.anuncio.idAnuncio}</strong></h2>
                    <p>{dadosAnuncio.anuncio.cidade}, {dadosAnuncio.anuncio.bairro} |  {dadosAnuncio.anuncio.rua} n° {dadosAnuncio.anuncio.numero}</p>
                </div>

                <div className="Card02_row2">
                    <p >Proprietario: <strong className="card02_link_proprietario" >{dadosAnuncio.anuncio.nome_usuario}</strong></p>
                </div>

                <div className="Card02_row3">
                    <div className="Card02_EntradaSaida">
                        <p>Entrada: {dadosAnuncio.anuncio.DataInicial}</p>
                        <p>Saida: {dadosAnuncio.anuncio.DataFinal}</p>
                    </div>
                    <p>Valor Pago: R$ x</p>
                </div>


                <div className="ratingCard02">
                    <i class="bi bi-star-fill "></i>
                    <p> {dadosAnuncio.anuncio.rating} </p>
                </div>
            </div>
        </div>
    )
}

export default Card02