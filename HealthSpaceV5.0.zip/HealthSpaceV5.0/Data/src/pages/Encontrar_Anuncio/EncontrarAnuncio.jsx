import { useState, useEffect, useRef } from "react"
import { useLocation, useNavigate } from "react-router-dom"
import axios from "axios"
import "./EncontrarAnuncio.css"


//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao";

//Components
import Header02 from "../../components/Header02/header02"
import Footer02 from "../../components/Footer02/footer02";

import Card01 from "../../components/Card 01/card01";
import RangeSlider from "../../components/RangeSlider/RangeSlider";

//icons
import IconGrid01 from "../../../public/Assets/Icons/Blacks/grid-1x2.svg"

function EncontrarAnuncio() {
    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    const navigate = useNavigate()
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(true)
    const [AnuncioHomeList, setAnuncioHomeList] = useState([])
    const [TemAnuncio, setTemAnuncio] = useState()

    const location = useLocation()
    const params = new URLSearchParams(location.search)

    const [FiltroCidade, setFiltroCidade] = useState(params.get('Cidade') ? params.get('Cidade') : "")
    const [APIArrayListaCidades, setAPIArrayListaCidades] = useState([])
    const [FiltroTipoSala, setFiltroTipoSala] = useState(params.get('TipoSala') ? params.get('TipoSala') : "Exibir_Tudo_TipoSala")
    const [FiltroPrecoMIN, setFiltroPrecoMIN] = useState(1)
    const [FiltroPrecoMAX, setFiltroPrecoMAX] = useState("Ilimitado")

    const [ArrayAnunciosFiltrados, setArrayAnunciosFiltrados] = useState([])


    const Filter_Box = useRef(null)
    useEffect(() => {
        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        //console.log(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                            })

                    } else {
                        setStatusLogin(false)
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)

        }

        axios.get(`${BaseUrl.url}/anuncio/listDisponivel`)
            .then(resposta => {
                if (resposta.data['TemAnuncios']) {
                    //console.log(resposta.data['resultado'])
                    setAnuncioHomeList(resposta.data['resultado'])
                    setTemAnuncio(true)
                } else {
                    setTemAnuncio(false)
                }

            })

        axios.get('https://servicodados.ibge.gov.br/api/v1/localidades/municipios')
            .then(resposta => {
                const cidades = resposta.data.map(cidade => cidade.nome)
                setAPIArrayListaCidades(resposta.data)
                //console.log(resposta.data);


            })
    }, [])



    useEffect(() => {
        filtrar()

    }, [FiltroCidade, FiltroTipoSala, FiltroPrecoMIN, FiltroPrecoMAX, AnuncioHomeList])

    function filtrar () {
        const Filtro = AnuncioHomeList.filter(anuncio => {
            const cidadeOk = FiltroCidade === "" || anuncio.cidade === FiltroCidade;
            const tipoSalaOk = FiltroTipoSala === "Exibir_Tudo_TipoSala" || anuncio.TipoSala === FiltroTipoSala; 
                    console.log("Cidade filtro:", FiltroCidade, "→", anuncio.cidade, "→", cidadeOk)

            const PrecoMinOk = FiltroPrecoMIN === 1 || anuncio.valor >= FiltroPrecoMIN
            const PrecoMaxOk = FiltroPrecoMAX === "Ilimitado" || anuncio.valor <= FiltroPrecoMAX

            return cidadeOk && tipoSalaOk && PrecoMinOk && PrecoMaxOk;
            
        });
        setArrayAnunciosFiltrados(Filtro)
        //console.log(Filtro)
    }


    return (
        <>
            <Header02 InfosUser={InfosUser} StatusLogin={StatusLogin} />
            <main className="Page_Encontrar_Anuncio">
                <section className="Section02_Page_Encontrar_Anuncio">
                    <div className="Page_Encontrar_Anuncio_Box_titulo">
                        <h1>Espaços encontrados de acordo com suas escolhas</h1>
                        <p>{ArrayAnunciosFiltrados.length} resultados</p>
                    </div>
                    <div className="Section02_Page_Encontrar_Anuncio_BoxCards">
                        {
                            ArrayAnunciosFiltrados.map((anuncio, index) => {
                                return (
                                    <Card01 key={index} anuncio={[anuncio]} />
                                )
                            })
                        }
                    </div>
                </section>
                <section className="Section01_Page_Encontrar_Anuncio">
                    <div className="BoxFilter_text1">
                        <i class="bi bi-funnel-fill"></i>
                        <p className="Filter_Text1">Busca avançada</p>
                    </div>
                    <hr className="border1"/>
                    
                    <div className="Filter_Box_input">
                        <i class="bi bi-geo-alt"></i>
                        <i className="bi bi-backspace-fill btn_clear" style={{ opacity: FiltroCidade != "" ? '100%' : '0%' }} onClick={() => setFiltroCidade('')}></i>
                        <input type="text" placeholder="Em que cidade você está?" value={FiltroCidade} onChange={(e) => { setFiltroCidade(e.target.value); Filter_Box.current.style.display = "flex" }} />
                        <div ref={Filter_Box} className="Filter_Box_input_search_cidade" onClick={() => Filter_Box.current.style.display = "none"}>
                            {
                                APIArrayListaCidades.filter(cidade => cidade.nome.toLowerCase().includes(FiltroCidade.toLowerCase())).map((cidade, index) => {
                                    return (
                                        <div key={index} className="Filter_Result" onClick={() => setFiltroCidade(cidade.nome)}>
                                            <i class="bi bi-search"></i>
                                            <div className="Filter_Result_dados">
                                                <p className="cidade">{cidade.nome}</p>
                                                <p className="uf"> {cidade?.microrregiao?.mesorregiao?.UF?.nome}</p>
                                            </div>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>

                    <div className="Filter_Box_input">
                        <i class="bi bi-grid-1x2"></i>
                        <select name="opcao" id="" onChange={(e) => setFiltroTipoSala(e.target.value)}>
                            <option value="Exibir_Tudo_TipoSala"> Exibir tudo</option>
                            <option value="Fisioterapia">Fisioterapia</option>
                            <option value="Oftalmologista">Oftamologista</option>
                            <option value="Psicologia">Psicologia</option>
                            <option value="Odontologia">Odontologia</option>

                        </select>
                    </div>  

                    <div className="Filter_Box_input">
                        <RangeSlider onChange={Pega_Preco_MIN_MAX} />
                    </div>
                </section>


            </main>
           <Footer02/>                 
        </>
    )

    function Pega_Preco_MIN_MAX(valores) {
        setFiltroPrecoMIN(valores[0])
        setFiltroPrecoMAX(valores[1] >= 1001 ? "Ilimitado" : valores[1])
    }
}

export default EncontrarAnuncio