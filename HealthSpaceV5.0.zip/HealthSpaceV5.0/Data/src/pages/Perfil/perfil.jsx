import "./perfil.css"
import { useState, useEffect, useRef } from "react"
import { useLocation, useNavigate, useParams } from "react-router-dom"
import axios from "axios"

//BaseUrl
import BaseUrl from "../../UrlBaseRequisicao";

//Components
import Header02 from "../../components/Header02/header02"
import Footer02 from "../../components/Footer02/footer02";
import Card_Avaliacao from "../../components/Card_Avaliacao/card_avaliacao";

//Imagens
import Ava1 from "../../../public/Assets/Imagens/ava1.jpg"
import Ava2 from "../../../public/Assets/Imagens/user.jpg"
function PerfilPage() {
    const { idUser } = useParams()
    console.log(idUser)
    const dados = {
        nome: "Visitante",
        HCoins: 0
    }
    const navigate = useNavigate()
    const [InfosUser, setInfosUser] = useState(dados)
    const [StatusLogin, setStatusLogin] = useState(true)

    const [PerfilDados, setPerfilDados] = useState([])
    const Ref_DIALOG_Edite_Perfil = useRef(null)

    useEffect(() => {

        const TokenStorage = localStorage.getItem("tokenJWT")
        if (TokenStorage) {
            axios.post(`${BaseUrl.url}/auth/authToken`, { token: TokenStorage })
                .then(resposta => {

                    if (resposta.data['TokenValidade']) {
                        const id = resposta.data['tokenDados'].id
                        //console.log(id)
                        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: id })
                            .then(resposta => {
                                setInfosUser(resposta.data['resultado'])
                                //console.log(resposta.data['resultado'])
                                setStatusLogin(true)
                            })

                    } else {
                        setStatusLogin(false)
                    }


                })

                .catch(err => {
                    setStatusLogin(false)
                    localStorage.removeItem("tokenJWT")
                    window.location.reload()
                    console.error("Erro ao validar token:", err)
                })
        } else {
            setStatusLogin(false)

        }

        axios.post(`${BaseUrl.url}/auth/InfosUser`, { id: idUser })
            .then(resposta => {
                const dados = resposta.data['resultado']
                setPerfilDados(dados)

                const DataCreateAccount = new Date(dados.DataCreateAccount)
                const Hoje = new Date()
                DataCreateAccount.setHours(0, 0, 0, 0, 0);
                Hoje.setHours(0, 0, 0, 0, 0)            
                const CalculoTempoPassado = Hoje - DataCreateAccount
                const DiasPassado = CalculoTempoPassado / 86400000 //86400000 milessegundos é igual a 1 dia

                const PegaAno = DataCreateAccount.getFullYear()
                let mensagemTempo;

                if (DiasPassado === 0){
                    mensagemTempo = "Há menos de um dia."
                }else if(DiasPassado === 1){
                    mensagemTempo = `Há ${DiasPassado} dia.`
                }else if(DiasPassado > 1 && DiasPassado < 365){
                    mensagemTempo = `Há ${Math.floor(DiasPassado)} dias.`
                }else if (DiasPassado >= 365 ){
                    const anos = Math.floor(DiasPassado / 365)
                    mensagemTempo = `Há ${anos} ano${anos > 1 ? "s." : "."}`
                }

                setPerfilDados(prev => ({
                    ...prev,
                    DataCreateAccount_Ano: `${PegaAno}`, DataCreateAccount_Dias: mensagemTempo
                }));
                //console.log(dados)

            })






    }, [])

    return (
        <>
            <Header02 InfosUser={InfosUser} StatusLogin={StatusLogin} />
            <main className="Page_Perfil">
                <section className="Section01_PerfilPage">
                    <div className="Card_avatar">
                        <div className="left">
                            <div class="avatar">
                                <img src={Ava1} alt="Foto de Perfil" />
                            </div>
                            <p>{PerfilDados.nome}</p>

                        </div>


                        <div className="right">
                            <p><strong>5.00 <i class="bi bi-star-fill"></i></strong> estrelas </p>
                            <hr className="border1" />
                            <p><strong>0</strong> avaliações </p>
                            <hr className="border1" />
                            <p><strong>0</strong> anuncios concluidas</p>
                            <hr className="border1" />
                            <p><strong>0</strong> reservas concluidas</p>
                        </div>

                        <p className="Id_Perfil">#{PerfilDados.id_usuario}</p>
                    </div>

                    <div className="Infos_Basics">
                        <h1>Sobre {PerfilDados.nome}</h1>
                        <div className="infos_user">
                            <p><strong><i class="bi bi-cake2"></i> </strong> Nasceu em 1998, tem 26 anos</p>
                            <p><strong><i class="bi bi-briefcase"></i> </strong> Trabalho com: Fisioterapeuta</p>
                            <p><strong><i class="bi bi-house"></i> </strong> Mora em Recife, Pernambuco</p>
                            <p><strong><i class="bi bi-door-open"></i> </strong> Entrou em {PerfilDados.DataCreateAccount_Ano}. <strong className="Cont_Tempo_Conta"> {PerfilDados.DataCreateAccount_Dias === 0 ? "Há menos de 1 dia" : PerfilDados.DataCreateAccount_Dias}</strong></p>
                            <p className="link"><strong><i class="bi bi-shield-check"></i> </strong> Perfil verificado</p>
                        </div>
                    </div>
                    {InfosUser.id_usuario === PerfilDados.id_usuario && (
                        <p className="Btn_EditPerfil" onClick={() => {Open_Close_Dialog_Edite_Perfil("Open")}}><i class="bi bi-pencil-square"></i> Editar perfil</p>

                    )}
                </section>

                <section className="Section02_PerfilPage">
                    <h1>Avaliações de {PerfilDados.nome}</h1>
                    <div className="Box_Avalaiacoes">

                        <div className="Box_Cards_Avaliacoes">
                            <Card_Avaliacao />
                            <Card_Avaliacao />
                            <Card_Avaliacao />
                        </div>

                        <p>Exibir as 250 avaliações</p>
                    </div>
                </section>  

                <dialog ref={Ref_DIALOG_Edite_Perfil} className="Dialog_Edite_Perfil">
                    <div className="Box_Content_Dialog_Edite_Perfil">
                        <i class="bi bi-x-square-fill" onClick={() => {Open_Close_Dialog_Edite_Perfil('Close')}}></i>
                    </div>
                </dialog>

            </main>
            <Footer02 />
        </>
    )

    function Open_Close_Dialog_Edite_Perfil(opcao){
        if(opcao === 'Open'){
            Ref_DIALOG_Edite_Perfil.current.showModal()
        }else if (opcao === 'Close'){
            Ref_DIALOG_Edite_Perfil.current.close()
        }
    }
}

export default PerfilPage