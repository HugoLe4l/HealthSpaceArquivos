-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 17/06/2025 às 22:33
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `healthspacedb`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `anuncios`
--

CREATE TABLE `anuncios` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `rua` varchar(255) NOT NULL,
  `numero` int(5) NOT NULL,
  `cep` char(9) NOT NULL,
  `descricao` text DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL,
  `DataInicial` date NOT NULL DEFAULT '1000-01-01',
  `DataFinal` date NOT NULL DEFAULT '1000-01-01',
  `HorarioAbertura` time NOT NULL,
  `HorarioFechamento` time NOT NULL,
  `rating` decimal(10,2) NOT NULL,
  `disponibilidade` tinyint(1) DEFAULT 1,
  `TipoSala` varchar(50) NOT NULL,
  `RecursosBasicos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`RecursosBasicos`)),
  `RecursosEspecificos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`RecursosEspecificos`)),
  `nome_usuario` varchar(255) DEFAULT NULL,
  `Url_imagem_1` varchar(500) NOT NULL,
  `Url_imagem_2` varchar(500) NOT NULL,
  `Url_imagem_3` varchar(500) NOT NULL,
  `Url_imagem_4` varchar(500) NOT NULL,
  `Url_imagem_5` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `anuncios`
--

INSERT INTO `anuncios` (`id`, `id_usuario`, `nome`, `cidade`, `bairro`, `rua`, `numero`, `cep`, `descricao`, `valor`, `DataInicial`, `DataFinal`, `HorarioAbertura`, `HorarioFechamento`, `rating`, `disponibilidade`, `TipoSala`, `RecursosBasicos`, `RecursosEspecificos`, `nome_usuario`, `Url_imagem_1`, `Url_imagem_2`, `Url_imagem_3`, `Url_imagem_4`, `Url_imagem_5`) VALUES
(189, 1, 'Espaço Zen para Atendimentos Psicológicos', 'Recife', 'Santo Antônio', 'Rua Siqueira Campos', 6, '50010010', 'Ambiente acolhedor e silencioso, ideal para psicólogos e terapeutas. Conta com poltronas confortáveis, iluminação suave e isolamento acústico. Localizado próximo ao metrô com recepção e café disponíveis.\r\n', 50.99, '2025-06-13', '2025-07-11', '18:00:00', '22:00:00', 0.00, 1, 'Psicologia', '[\"Wi-fi\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\",\"Elevador\",\"Recepção\"]', '[\"Sala de atendimento individual\",\"Sala de atendimento em grupo\",\"Mesa de trabalho\",\"Iluminação suave\",\"Cadeiras confortáveis\"]', 'Hugo', '1JnF78Xeae_3lC7gpXmlP_ADfmJCxN8yh', '1_t5hk8dISVFk4LIqHyzt64wipxUtktTO', '1R8z71M7YYDDU8uxckmRz3--BeBhon3SB', '1hWK72jw-5GqwTAH4LiiM2pMx3pD8rlIr', '1nSNTAoHOL7zURIs9EYGtu2vtkOQ9v0Qx'),
(190, 1, 'Studio Equipado para Fisioterapia', 'Recife', 'Santo Antônio', 'Praça da República', 2, '50010040', 'Espaço moderno com equipamentos como bola suíça, tatames, barras paralelas e espaldar. Ideal para fisioterapeutas que atuam com reabilitação, pilates solo e funcional. Fácil acesso e estacionamento no local.', 54.12, '2025-06-27', '2025-07-06', '18:00:00', '23:00:00', 0.00, 1, 'Fisioterapia', '[\"Wi-fi\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\"]', '[\"Mesa de massagem\",\"Equipamento de hidroterapia\",\"Equipamento de eletroterapia\"]', 'Hugo', '1kkUvoNpGIae8w0LzzcwCceMDbu_ODLYy', '13OrHXo8Ox_foyE1YlYnH8hPySXrmMOzF', '1GUeEIjnEcV4pj8WQKsLFMp4yhDdT5ti9', '1Y0YMd-pH5ryRkFoecRaPA-JnoOe1souX', '1A02Etl6pvS4c8682lH4hBOKNbBi_XP7I'),
(191, 1, 'Espaço para Exames ', 'Recife', 'Santo Antônio', 'Rua Frei Vicente do Salvador', 56, '50010030', 'Consultório equipado com cadeira de exames, mesa para autorefrator e iluminação adequada. Ideal para exames de rotina e triagem oftalmológica. Prédio com acessibilidade e recepção.', 123.45, '2025-06-24', '2025-06-30', '10:00:00', '20:00:00', 0.00, 1, 'Oftalmologista', '[\"Wi-fi\",\"Recepção\",\"Elevador\"]', '[\"Lensômetro\",\"Tabela de Snellen\",\"Lupas e espelhos\"]', 'Hugo', '1nVrjIfRUS1Kp13z4GfezsUYd9lulCGf3', '1bPmsGIntmqmJB66sLYSA7NymXXy7IlAI', '1-JAABq1dah2ZJY8cP5ZxccyNVqhtiHGC', '1xj-RMTg7a14ZcMhnrnfat6r8HB8ZFEI8', '1oJZlpCWMCirCfXpxPgSOY9UPRO4WoOLm'),
(192, 1, 'Espaço Odontológico', 'São Paulo', 'Sé', 'Praça da Sé', 12, '01001000', 'Local moderno, climatizado e bem localizado, com todos os equipamentos odontológicos necessários. Recepção compartilhada e suporte para agenda e prontuários digitais.', 43.56, '2025-06-13', '2025-06-23', '11:00:00', '22:00:00', 0.00, 1, 'Odontologia', '[\"Wi-fi\",\"Recepção\",\"Elevador\",\"Estacionamento\"]', '[\"Cadeira odontológica\",\"Refletor\",\"Fotopolimerizador\",\"Aparelho de raio-x\"]', 'Hugo', '1Lctgc8gR25_Rl81yob-mCAEDdFC2Txd_', '1k1gVbWaE7YeB6JebNf4OrupL11my-YTx', '19scoMTbenIL-6CL0Y8Uahy75MybMwEER', '1R1sQ690mHKHzNRuUIs7vYmpMpHUtgckX', '11K_kHig_U5XgoOawjDanD9hnXma2oXxX'),
(193, 1, 'Sala de Fisio', 'São Paulo', 'Bela Vista', 'Avenida Paulista', 45, '01310923', 'Ambiente espaçoso, com maca profissional, espelho de parede e materiais de apoio. Ideal para atendimentos individuais ou em dupla. Ambiente bem ventilado e com fácil agendamento.', 84.56, '2025-06-10', '2025-06-12', '08:00:00', '19:00:00', 0.00, 1, 'Fisioterapia', '[\"Wi-fi\",\"Ar-condicionado\",\"Banheiro\",\"Recepção\"]', '[\"Aparelho de laser\",\"Equipamento de hidroterapia\",\"Equipamento de eletroterapia\"]', 'Hugo', '1EdgrKMJTsRrOa_du_ryCrrruo1oOMi6q', '1yR1Cvn-igAxCo6DP6p7D8iK6XGkts4fX', '1QK66tX__hWTPMk94ldBMJhTgCPgqn3xC', '1eB6PWZhv0RSh7CJZayVdSBWSjFrY6V3L', '1oxVE4PKYVZCzqlPj7WwWRzwELjHQYAkk'),
(194, 38, 'Sala Fisioterapia Esportiva', 'Recife', 'Água Fria', 'Rua Córrego Antônio Rodrigues', 54, '52211050', 'Espaço amplo com piso emborrachado, ideal para atendimentos de atletas e reabilitação esportiva. Equipamentos como kettlebells, faixas elásticas, halteres e bola suíça inclusos. Vestiário e bebedouro disponíveis.', 35.99, '2025-06-06', '2025-06-18', '10:00:00', '17:00:00', 0.00, 1, 'Fisioterapia', '[\"Wi-fi\",\"Recepção\",\"Elevador\",\"Banheiro\",\"Ar-condicionado\"]', '[\"Equipamento de hidroterapia\",\"Equipamento de eletroterapia\",\"Aparelho de laser\"]', 'Jorge', '1n67hytQ7m1rReFvS56XiQZbyarligVnd', '1wpRTIUjx3FtWb_KxNEHFvlNnsGqGcu-U', '1h9AlhVQpUI6ev59v-ooycvrFkR6mtpth', '1wNhRSWY14P3W-iOUsk4JWMTkE75kyvNK', '1uZbO8RBFIL_8-PY0t6a5F9OHueedbzHA'),
(195, 38, 'Consultório Fisio+', 'Recife', 'Guabiraba', 'Estrada da FOP', 123, '52171210', 'Consultório Fisio+ – Ideal para Tratamentos Personalizados\r\n\r\nSala confortável com maca elétrica, armário para materiais, som ambiente e climatização. Indicado para profissionais que realizam atendimentos de RPG, pilates clínico ou fisioterapia ortopédica.', 120.00, '2025-06-20', '2025-07-12', '10:00:00', '21:00:00', 0.00, 1, 'Fisioterapia', '[\"Wi-fi\",\"Ar-condicionado\",\"Estacionamento\",\"Elevador\",\"Banheiro\"]', '[\"Aparelho de laser\",\"Mesa de massagem\",\"Equipamento de termoterapia\",\"Cama de Fisioterapia\",\"Equipamento de eletroterapia\",\"Equipamento de hidroterapia\"]', 'Jorge', '1yIrlGmj-urvz3ldxrueopepz4W_yOLuC', '1OANISg666flH7P4TwfelWU8TOhrMvmeB', '1Fok7NNPpJFppuWtUHtnmQsZ4z7gfYJkc', '1f_hljzzTYnjYbLahj5DyI2bTCAORX7h2', '1gQoD1ek4wCK1R-K95lHT_asStaO84UYl'),
(196, 38, 'Sala Oftalmo', 'Santo Antônio de Jesus', 'Nossa Senhora das Graças', 'Rua Via Coletora B', 45, '44444444', 'Ambiente planejado para oftalmologistas, com iluminação técnica, ar-condicionado e espaço para equipamentos como lâmpada de fenda e projetor de optotipos. Próximo a clínicas e laboratórios.', 123.45, '2025-06-13', '2025-06-20', '18:00:00', '20:00:00', 0.00, 1, 'Oftalmologista', '[\"Wi-fi\",\"Recepção\",\"Elevador\",\"Estacionamento\"]', '[\"Lensômetro\",\"Armários e bancadas para organização\",\"Lupas e espelhos\",\"Tabela de Snellen\"]', 'Jorge', '1GwonFhznC3mJBvXOFK2dItvbFle4Ca-s', '1jMt7ktZTJabpneVBTPAwibrI6bbBB1yx', '1h-DETkjcNWj5T3B6p9KE7BT7Sg_lchfI', '1nD5IF5zOrEkYM-fFoEk5J51F7xpK0PQ0', '1C8DO03jaKE7-CpqE27pPdUBvyt2yhtWf'),
(197, 38, 'Sala Odonto Premium', 'Camaragibe', 'Bairro dos Estados', '1ª Travessa Bom Jesus', 12, '54762224', 'Local moderno, climatizado e bem localizado, com todos os equipamentos odontológicos necessários. Recepção compartilhada e suporte para agenda e prontuários digitais.', 123.45, '2025-06-20', '2025-07-11', '10:00:00', '20:00:00', 0.00, 1, 'Odontologia', '[\"Wi-fi\",\"Elevador\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\",\"Recepção\"]', '[\"Cadeira odontológica\",\"Aparelho de raio-x\",\"Sucção\",\"Mocho\",\"Fotopolimerizador\",\"Refletor\"]', 'Jorge', '1CFTLvQcCaiblEy2o2poTD2rWyrCjmCbv', '1claQToAIgdxZ-n1X4R-d3C864EUDt6b0', '1amPELrnQUAMnJFje_X-WuQiqZJaDSbFW', '13cO4PZ1zi8Wd0Tu9tyXbLLjuGM8XcNF-', '1-B-RxyyPT9i4j7SMPLOv3gvAHGbwUXS4'),
(198, 38, 'Sala Fisio Equilíbrio', 'Recife', 'Boa Viagem', 'Rua Professor Ruy Baptista', 45, '51020160', 'Ambiente calmo, bem decorado e com isolamento sonoro. Conta com som ambiente, maca fixa, suporte para rolos e faixas. Indicado para técnicas manuais, reabilitação postural e relaxamento muscular.', 54.12, '2025-06-13', '2025-06-27', '10:00:00', '20:00:00', 0.00, 1, 'Fisioterapia', '[\"Wi-fi\",\"Estacionamento\",\"Elevador\"]', '[\"Equipamento de hidroterapia\",\"Equipamento de eletroterapia\",\"Mesa de massagem\",\"Aparelho de laser\"]', 'Jorge', '1Fd5JQ2s2BqPKS1kii6I7E3IEUY3BFH9D', '1PPgXkRzmwJlaN1p_kaOg8BXEc4wLHuyj', '1LiW7NAWEfKwanQl2ymMUh2dgAyYWhiKa', '14O7D3pW2PWQfeymgbUgjuL-wl8L4s4rR', '1_noRmTi7TxodfXvTEh4PpiHeTuCaElrg'),
(199, 38, 'Clínica Compartilhada', 'Recife', 'Boa Viagem', 'Rua Jean Mermoz', 5, '51130330', 'Espaço compartilhado entre profissionais da saúde, com área de atendimento privativa, recepção e acesso a equipamentos como tens, ultrassom e infravermelho. Perfeito para parcerias e troca de indicações.', 25.23, '2025-06-26', '2025-07-10', '18:00:00', '20:00:00', 0.00, 1, 'Oftalmologista', '[\"Wi-fi\",\"Recepção\",\"Elevador\",\"Estacionamento\",\"Ar-condicionado\",\"Banheiro\"]', '[\"Cadeira e coluna oftalmológica\",\"Lupas e espelhos\",\"Armários e bancadas para organização\",\"Lensômetro\",\"Tabela de Snellen\"]', 'Jorge', '1UX5jsM7ro8xuEFRlAinL17P3RGcW-mwD', '1-tRexe-rn03u4Xq10LnCLuM9qUjHhwVH', '12VspZORiZVBtcq28ogMOIEbN2EOVWqKs', '1ufVDsrTcOk998NFEjkqmrAdFhCopTSAK', '147aWEEtuuWdas8W9SUWogLlNFB3tt_Z7'),
(200, 36, 'Espaço Compacto ', 'Recife', 'Santo Antônio', 'Avenida Guararapes', 23, '50010000', 'Ideal para atendimentos rápidos ou pacientes recorrentes. Sala mobiliada com maca, suporte para toalhas, pia e armário. Local discreto e de fácil acesso, próximo a pontos de transporte público.', 23.45, '2025-06-12', '2025-06-27', '18:00:00', '20:00:00', 0.00, 1, 'Fisioterapia', '[\"Wi-fi\",\"Recepção\",\"Elevador\"]', '[\"Aparelho de laser\",\"Equipamento de hidroterapia\",\"Equipamento de eletroterapia\",\"Mesa de massagem\"]', 'Julia', '1kAlWZUuSSwSpe_741MBPUd5L1ITR9V94', '1-eUJGWiHWUit24caw8Pn2IBcqvnXp_kF', '1VA3l3FXCECC7FMp8oVfni8HArpaM26P3', '1PSK4hD9sYRgzKqGWEzUVxk9cOSly3qBm', '17tYDRdl5zwZZbcfvilqOK1coO2RHbgAp'),
(201, 36, 'Estúdio Terapêutico', 'Recife', 'Santo Antônio', 'Praça da República', 23, '50010040', 'Ambiente reservado com tatames, espelhos, suportes para elásticos e colchonetes. Ótimo para fisioterapeutas que trabalham com movimento funcional, neurologia ou reabilitação infantil.', 242.34, '2025-06-28', '2025-07-10', '10:00:00', '22:00:00', 0.00, 1, 'Fisioterapia', '[\"Wi-fi\",\"Recepção\",\"Estacionamento\",\"Elevador\"]', '[\"Aparelho de laser\",\"Equipamento de hidroterapia\"]', 'Julia', '17VuPjoB344tZHO0OWO3h8JNaeVxIaZNk', '1Ukp6EZu_0abicMRuowtK5p5ezMwGHc4M', '1cZhOty5cTo1wjzPp6J34o7dl1_E0Ubwo', '1QJe5Hi4C898VfQuKhn1gVcCt3A4whe5H', '1PJVci8bLXSO5hFWkjHlG8lU45xxZxAxo');

-- --------------------------------------------------------

--
-- Estrutura para tabela `datas`
--

CREATE TABLE `datas` (
  `id_data` int(11) NOT NULL,
  `id_anuncio` int(11) NOT NULL,
  `Data_Disponivel` date NOT NULL,
  `Status` enum('Disponivel','Reservado','Cancelada','Concluida','Expirada') NOT NULL DEFAULT 'Disponivel'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `datas`
--

INSERT INTO `datas` (`id_data`, `id_anuncio`, `Data_Disponivel`, `Status`) VALUES
(270, 189, '2025-06-13', 'Disponivel'),
(271, 189, '2025-06-14', 'Disponivel'),
(272, 189, '2025-06-15', 'Disponivel'),
(273, 189, '2025-06-16', 'Disponivel'),
(274, 189, '2025-06-17', 'Disponivel'),
(275, 189, '2025-06-18', 'Disponivel'),
(276, 189, '2025-06-19', 'Disponivel'),
(277, 189, '2025-06-20', 'Disponivel'),
(278, 189, '2025-06-21', 'Disponivel'),
(279, 189, '2025-06-22', 'Disponivel'),
(280, 189, '2025-06-23', 'Disponivel'),
(281, 189, '2025-06-24', 'Disponivel'),
(282, 189, '2025-06-25', 'Disponivel'),
(283, 189, '2025-06-26', 'Disponivel'),
(284, 189, '2025-06-27', 'Disponivel'),
(285, 189, '2025-06-28', 'Disponivel'),
(286, 189, '2025-06-29', 'Disponivel'),
(287, 189, '2025-06-30', 'Disponivel'),
(288, 189, '2025-07-01', 'Disponivel'),
(289, 189, '2025-07-02', 'Disponivel'),
(290, 189, '2025-07-03', 'Disponivel'),
(291, 189, '2025-07-04', 'Disponivel'),
(292, 189, '2025-07-05', 'Disponivel'),
(293, 189, '0000-00-00', 'Disponivel'),
(294, 189, '0000-00-00', 'Disponivel'),
(295, 189, '0000-00-00', 'Disponivel'),
(296, 189, '0000-00-00', 'Disponivel'),
(297, 189, '0000-00-00', 'Disponivel'),
(298, 189, '0000-00-00', 'Disponivel'),
(299, 190, '2025-06-27', 'Disponivel'),
(300, 190, '2025-06-28', 'Disponivel'),
(301, 190, '2025-06-29', 'Disponivel'),
(302, 190, '2025-06-30', 'Disponivel'),
(303, 190, '2025-07-01', 'Disponivel'),
(304, 190, '2025-07-02', 'Disponivel'),
(305, 190, '2025-07-03', 'Disponivel'),
(306, 190, '2025-07-04', 'Disponivel'),
(307, 190, '2025-07-05', 'Disponivel'),
(308, 190, '2025-07-06', 'Disponivel'),
(309, 191, '2025-06-24', 'Disponivel'),
(310, 191, '2025-06-25', 'Disponivel'),
(311, 191, '2025-06-26', 'Disponivel'),
(312, 191, '2025-06-27', 'Disponivel'),
(313, 191, '2025-06-28', 'Disponivel'),
(314, 191, '2025-06-29', 'Disponivel'),
(315, 191, '2025-06-30', 'Disponivel'),
(316, 192, '2025-06-13', 'Disponivel'),
(317, 192, '2025-06-14', 'Disponivel'),
(318, 192, '2025-06-15', 'Disponivel'),
(319, 192, '2025-06-16', 'Disponivel'),
(320, 192, '2025-06-17', 'Disponivel'),
(321, 192, '2025-06-18', 'Disponivel'),
(322, 192, '2025-06-19', 'Disponivel'),
(323, 192, '2025-06-20', 'Disponivel'),
(324, 192, '2025-06-21', 'Disponivel'),
(325, 192, '2025-06-22', 'Disponivel'),
(326, 192, '2025-06-23', 'Disponivel'),
(327, 193, '2025-06-10', 'Disponivel'),
(328, 193, '2025-06-11', 'Disponivel'),
(329, 193, '2025-06-12', 'Disponivel'),
(330, 194, '2025-06-06', 'Disponivel'),
(331, 194, '2025-06-07', 'Disponivel'),
(332, 194, '2025-06-08', 'Disponivel'),
(333, 194, '2025-06-09', 'Disponivel'),
(334, 194, '2025-06-10', 'Disponivel'),
(335, 194, '2025-06-11', 'Disponivel'),
(336, 194, '2025-06-12', 'Disponivel'),
(337, 194, '2025-06-13', 'Disponivel'),
(338, 194, '2025-06-14', 'Disponivel'),
(339, 194, '2025-06-15', 'Disponivel'),
(340, 194, '2025-06-16', 'Disponivel'),
(341, 194, '2025-06-17', 'Disponivel'),
(342, 194, '2025-06-18', 'Disponivel'),
(343, 195, '2025-06-20', 'Disponivel'),
(344, 195, '2025-06-21', 'Disponivel'),
(345, 195, '2025-06-22', 'Disponivel'),
(346, 195, '2025-06-23', 'Disponivel'),
(347, 195, '2025-06-24', 'Disponivel'),
(348, 195, '2025-06-25', 'Disponivel'),
(349, 195, '2025-06-26', 'Disponivel'),
(350, 195, '2025-06-27', 'Disponivel'),
(351, 195, '2025-06-28', 'Disponivel'),
(352, 195, '2025-06-29', 'Disponivel'),
(353, 195, '2025-06-30', 'Disponivel'),
(354, 195, '2025-07-01', 'Disponivel'),
(355, 195, '2025-07-02', 'Disponivel'),
(356, 195, '2025-07-03', 'Disponivel'),
(357, 195, '2025-07-04', 'Disponivel'),
(358, 195, '2025-07-05', 'Disponivel'),
(359, 195, '2025-07-06', 'Disponivel'),
(360, 195, '2025-07-07', 'Disponivel'),
(361, 195, '2025-07-08', 'Disponivel'),
(362, 195, '2025-07-09', 'Disponivel'),
(363, 195, '2025-07-10', 'Disponivel'),
(364, 195, '2025-07-11', 'Disponivel'),
(365, 195, '2025-07-12', 'Disponivel'),
(366, 196, '2025-06-13', 'Disponivel'),
(367, 196, '2025-06-14', 'Disponivel'),
(368, 196, '2025-06-15', 'Disponivel'),
(369, 196, '2025-06-16', 'Disponivel'),
(370, 196, '2025-06-17', 'Disponivel'),
(371, 196, '2025-06-18', 'Disponivel'),
(372, 196, '2025-06-19', 'Disponivel'),
(373, 196, '2025-06-20', 'Disponivel'),
(374, 197, '2025-06-20', 'Disponivel'),
(375, 197, '2025-06-21', 'Disponivel'),
(376, 197, '2025-06-22', 'Disponivel'),
(377, 197, '2025-06-23', 'Disponivel'),
(378, 197, '2025-06-24', 'Disponivel'),
(379, 197, '2025-06-25', 'Disponivel'),
(380, 197, '2025-06-26', 'Disponivel'),
(381, 197, '2025-06-27', 'Disponivel'),
(382, 197, '2025-06-28', 'Disponivel'),
(383, 197, '2025-06-29', 'Disponivel'),
(384, 197, '2025-06-30', 'Disponivel'),
(385, 197, '2025-07-01', 'Disponivel'),
(386, 197, '2025-07-02', 'Disponivel'),
(387, 197, '2025-07-03', 'Disponivel'),
(388, 197, '2025-07-04', 'Disponivel'),
(389, 197, '2025-07-05', 'Disponivel'),
(390, 197, '2025-07-06', 'Disponivel'),
(391, 197, '2025-07-07', 'Disponivel'),
(392, 197, '2025-07-08', 'Disponivel'),
(393, 197, '2025-07-09', 'Disponivel'),
(394, 197, '2025-07-10', 'Disponivel'),
(395, 197, '2025-07-11', 'Disponivel'),
(396, 198, '2025-06-13', 'Disponivel'),
(397, 198, '2025-06-14', 'Disponivel'),
(398, 198, '2025-06-15', 'Disponivel'),
(399, 198, '2025-06-16', 'Disponivel'),
(400, 198, '2025-06-17', 'Disponivel'),
(401, 198, '2025-06-18', 'Disponivel'),
(402, 198, '2025-06-19', 'Disponivel'),
(403, 198, '2025-06-20', 'Disponivel'),
(404, 198, '2025-06-21', 'Disponivel'),
(405, 198, '2025-06-22', 'Disponivel'),
(406, 198, '2025-06-23', 'Disponivel'),
(407, 198, '2025-06-24', 'Disponivel'),
(408, 198, '2025-06-25', 'Disponivel'),
(409, 198, '2025-06-26', 'Disponivel'),
(410, 198, '2025-06-27', 'Disponivel'),
(411, 199, '2025-06-26', 'Disponivel'),
(412, 199, '2025-06-27', 'Disponivel'),
(413, 199, '2025-06-28', 'Disponivel'),
(414, 199, '2025-06-29', 'Disponivel'),
(415, 199, '2025-06-30', 'Disponivel'),
(416, 199, '2025-07-01', 'Disponivel'),
(417, 199, '2025-07-02', 'Disponivel'),
(418, 199, '2025-07-03', 'Disponivel'),
(419, 199, '2025-07-04', 'Disponivel'),
(420, 199, '2025-07-05', 'Disponivel'),
(421, 199, '2025-07-06', 'Disponivel'),
(422, 199, '2025-07-07', 'Disponivel'),
(423, 199, '2025-07-08', 'Disponivel'),
(424, 199, '2025-07-09', 'Disponivel'),
(425, 199, '2025-07-10', 'Disponivel'),
(426, 200, '2025-06-12', 'Disponivel'),
(427, 200, '2025-06-13', 'Disponivel'),
(428, 200, '2025-06-14', 'Disponivel'),
(429, 200, '2025-06-15', 'Disponivel'),
(430, 200, '2025-06-16', 'Disponivel'),
(431, 200, '2025-06-17', 'Disponivel'),
(432, 200, '2025-06-18', 'Disponivel'),
(433, 200, '2025-06-19', 'Disponivel'),
(434, 200, '2025-06-20', 'Disponivel'),
(435, 200, '2025-06-21', 'Disponivel'),
(436, 200, '2025-06-22', 'Disponivel'),
(437, 200, '2025-06-23', 'Disponivel'),
(438, 200, '2025-06-24', 'Disponivel'),
(439, 200, '2025-06-25', 'Disponivel'),
(440, 200, '2025-06-26', 'Disponivel'),
(441, 200, '2025-06-27', 'Disponivel'),
(442, 201, '2025-06-28', 'Disponivel'),
(443, 201, '2025-06-29', 'Disponivel'),
(444, 201, '2025-06-30', 'Disponivel'),
(445, 201, '2025-07-01', 'Disponivel'),
(446, 201, '2025-07-02', 'Disponivel'),
(447, 201, '2025-07-03', 'Disponivel'),
(448, 201, '2025-07-04', 'Disponivel'),
(449, 201, '2025-07-05', 'Disponivel'),
(450, 201, '2025-07-06', 'Disponivel'),
(451, 201, '2025-07-07', 'Disponivel'),
(452, 201, '2025-07-08', 'Disponivel'),
(453, 201, '2025-07-09', 'Disponivel'),
(454, 201, '2025-07-10', 'Disponivel');

-- --------------------------------------------------------

--
-- Estrutura para tabela `reservas_confirmadas`
--

CREATE TABLE `reservas_confirmadas` (
  `id_reserva` int(11) NOT NULL,
  `id_anuncio` int(11) NOT NULL,
  `id_reservante` int(11) NOT NULL,
  `Data_Reservada` date NOT NULL,
  `ValorPago` float NOT NULL,
  `Data` datetime NOT NULL,
  `Codigo_reserva` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `senha` varchar(500) NOT NULL,
  `HCoins` bigint(11) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `DataCreateAccount` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nome`, `email`, `senha`, `HCoins`, `role`, `DataCreateAccount`) VALUES
(1, 'Hugo', 'Hugo@gmail.com', '$2b$10$LTmc5F.TBZh2sRCvw9F11OJaE62QMTPiac/i37IWx8LAVHvPUVAbG', 9223372036846539000, 'user', '2020-03-01 02:50:30'),
(36, 'Julia', 'Julia@gmail.com', '$2b$10$AM4w1YrPelml3JJJPQXn9.ChLFuLyQ8JcjZr2Aw3ez7KXmXNfly/a', 460, 'user', '2025-06-17 02:50:30'),
(37, 'Rafael', 'Rafael@gmail.com', '$2b$10$hyqReh/WQF7i8m1sOajqBeeBX4x6GxDwd5bB60xym/EaVZ/YD09Uu', 0, 'user', '2025-06-17 02:50:30'),
(38, 'Jorge', 'Jorge@gmail.com', '$2b$10$nbASevDnZo/b2BpJ6SZK.enVr1m9SSrkmIjJMGJ9B/2cwvJsWZyie', 0, 'user', '2025-06-17 02:50:30'),
(39, 'Manoel', 'Manoel@gmail.com', '123', 600, 'user', '2025-06-17 02:51:25');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `anuncios`
--
ALTER TABLE `anuncios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Índices de tabela `datas`
--
ALTER TABLE `datas`
  ADD PRIMARY KEY (`id_data`),
  ADD KEY `id_anuncio` (`id_anuncio`);

--
-- Índices de tabela `reservas_confirmadas`
--
ALTER TABLE `reservas_confirmadas`
  ADD PRIMARY KEY (`id_reserva`),
  ADD KEY `id` (`id_reservante`),
  ADD KEY `id_ad` (`id_anuncio`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `anuncios`
--
ALTER TABLE `anuncios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT de tabela `datas`
--
ALTER TABLE `datas`
  MODIFY `id_data` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=455;

--
-- AUTO_INCREMENT de tabela `reservas_confirmadas`
--
ALTER TABLE `reservas_confirmadas`
  MODIFY `id_reserva` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `anuncios`
--
ALTER TABLE `anuncios`
  ADD CONSTRAINT `anuncios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Restrições para tabelas `datas`
--
ALTER TABLE `datas`
  ADD CONSTRAINT `id_anuncio` FOREIGN KEY (`id_anuncio`) REFERENCES `anuncios` (`id`);

--
-- Restrições para tabelas `reservas_confirmadas`
--
ALTER TABLE `reservas_confirmadas`
  ADD CONSTRAINT `id` FOREIGN KEY (`id_reservante`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `id_ad` FOREIGN KEY (`id_anuncio`) REFERENCES `anuncios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
