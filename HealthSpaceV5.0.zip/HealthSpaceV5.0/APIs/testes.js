function CriarDatas(DataInicial, DataFinal) {
        // Converte as datas de string para objetos Date

        const [dia1, mes1, ano1] = DataInicial.split('-');
        const [dia2, mes2, ano2] = DataFinal.split('-');

        const DataInicialObj = new Date(`${ano1}-${mes1}-${dia1}T00:00:00Z`);
        const DataFinalObj = new Date(`${ano2}-${mes2}-${dia2}T00:00:00Z`);

        let x = 0;
        let Datas = [];

        while (DataInicialObj <= DataFinalObj) {
            x += 1;
            const DataFormatada = DataInicialObj.toISOString().split("T")[0]; // Formato 'YYYY-MM-DD'
            Datas.push(DataFormatada + `=${x}`);

            // Avança um dia
            DataInicialObj.setDate(DataInicialObj.getDate() + 1);
        }

        return Datas;
    }

    // Teste da função com datas fornecidas
    const ArrayDatas = CriarDatas('20-05-2025', '10-06-2025');
    console.log(ArrayDatas);